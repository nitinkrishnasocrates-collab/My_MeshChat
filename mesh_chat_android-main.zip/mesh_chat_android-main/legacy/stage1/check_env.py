"""
Stage 1 environment check.

Confirms that Python is working and that the standard-library modules
MeshChat will rely on in the early stages are all importable.

Run:
    python check_env.py
"""

import sys


def main() -> None:
    print("MeshChat - Environment Check")
    print("-" * 40)
    print(f"Python version: {sys.version}")
    print(f"Platform: {sys.platform}")

    required_modules = ["socket", "threading", "json", "uuid", "sqlite3", "dataclasses"]
    print("\nChecking standard library modules used by early stages:")

    all_ok = True
    for name in required_modules:
        try:
            __import__(name)
            print(f"  [OK]   {name}")
        except ImportError:
            print(f"  [FAIL] {name}")
            all_ok = False

    print("-" * 40)
    if all_ok:
        print("Environment looks good. Ready for Stage 2 (TCP sockets).")
    else:
        print("Some modules failed to import. Check your Python installation.")


if __name__ == "__main__":
    main()
