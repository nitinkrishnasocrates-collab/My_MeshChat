# MeshChat

An offline, peer-to-peer messaging system. Devices exchange text messages
without internet, without cellular data, without a central server, and
without a Wi-Fi router — using direct device-to-device transports (starting
with TCP sockets for local development, later Bluetooth and other nearby
transports).

## Status

🚧 **Stage 1 — Environment setup.** Nothing functional yet. This is the
skeleton the rest of the project builds on.

## Planned Architecture

```
UI
 ↓
Application / Messaging
 ↓
Routing (mesh)
 ↓
Peer Management
 ↓
Transport Interface
 ↓
Bluetooth / Wi-Fi Direct / TCP (dev only)
```

## Project Structure

```
MeshChat/
├── client/       # chat client
├── server/       # TCP server (Stage 2+)
├── protocol/     # message format, serialization
├── network/       # node/peer abstractions
├── mesh/         # routing logic
├── bluetooth/    # Bluetooth transport (later stage)
├── database/     # SQLite persistence (store-and-forward)
├── security/     # encryption, key management
├── mobile/       # Android app (later stage)
├── tests/        # unit + integration tests
└── docs/         # architecture notes, diagrams
```

## Setup

```powershell
cd C:\Projects\MeshChat
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python check_env.py
```

## Limitations (will stay true throughout early stages)

- No internet/cloud dependency by design — but early stages use TCP over
  localhost/LAN for learning purposes before Bluetooth is introduced.
- Message range is limited by the transport in use (Bluetooth range,
  physical obstacles, OS background restrictions) — relays extend reach
  only as far as there are intermediate devices.
- No feature is claimed as "done" until it's implemented and tested.

## Roadmap

See the staged build plan we're following — TCP sockets → two-way chat →
message protocol → multi-node → mesh routing → store-and-forward →
Bluetooth → Android → encryption → reliability → testing → polish.
