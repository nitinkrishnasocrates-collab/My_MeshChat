"""Command-line TCP chat client for MeshChat Stage 2."""
import argparse
import json
import socket
import threading

def receive_messages(sock):
    file = sock.makefile("r", encoding="utf-8")
    try:
        for line in file:
            try:
                data = json.loads(line)
            except json.JSONDecodeError:
                continue
            if data.get("type") == "chat":
                print(f"\n{data.get('name', 'Unknown')}: {data.get('text', '')}")
            elif data.get("type") == "system":
                print(f"\n[SYSTEM] {data.get('text', '')}")
            print("> ", end="", flush=True)
    except OSError:
        pass
    print("\n[Disconnected from server]")

def main():
    parser = argparse.ArgumentParser(description="MeshChat TCP client")
    parser.add_argument("--host", default="127.0.0.1", help="Server IP address")
    parser.add_argument("--port", type=int, default=5050)
    parser.add_argument("--name", default="Guest")
    args = parser.parse_args()

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.connect((args.host, args.port))
    except OSError as exc:
        print(f"Could not connect to {args.host}:{args.port}: {exc}")
        print("Check that the server is running and the IP/port are correct.")
        return

    sock.sendall((json.dumps({"type": "hello", "name": args.name}) + "\n").encode("utf-8"))
    threading.Thread(target=receive_messages, args=(sock,), daemon=True).start()
    print("Connected to MeshChat. Type a message and press Enter. Use /quit to exit.")
    try:
        while True:
            text = input("> ").strip()
            if not text:
                continue
            sock.sendall((json.dumps({"type": "chat", "text": text}) + "\n").encode("utf-8"))
            if text.lower() == "/quit":
                break
    except (KeyboardInterrupt, EOFError, OSError):
        pass
    finally:
        try:
            sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        sock.close()

if __name__ == "__main__":
    main()
