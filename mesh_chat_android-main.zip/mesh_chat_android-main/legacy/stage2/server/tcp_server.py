"""Threaded TCP chat server for MeshChat Stage 2."""
import argparse
import json
import socket
import threading

clients = {}
clients_lock = threading.Lock()

def send_json(conn, payload):
    data = (json.dumps(payload, ensure_ascii=False) + "\n").encode("utf-8")
    conn.sendall(data)

def broadcast(payload, exclude=None):
    dead = []
    with clients_lock:
        targets = list(clients.items())
    data = (json.dumps(payload, ensure_ascii=False) + "\n").encode("utf-8")
    for conn, name in targets:
        if conn is exclude:
            continue
        try:
            conn.sendall(data)
        except OSError:
            dead.append(conn)
    for conn in dead:
        remove_client(conn)

def remove_client(conn):
    with clients_lock:
        name = clients.pop(conn, None)
    try:
        conn.close()
    except OSError:
        pass
    if name:
        print(f"[LEFT] {name}")
        broadcast({"type": "system", "text": f"{name} left the chat"})

def handle_client(conn, address):
    name = None
    file = conn.makefile("r", encoding="utf-8")
    try:
        first = file.readline()
        if not first:
            return
        hello = json.loads(first)
        name = str(hello.get("name", "Guest")).strip()[:24] or "Guest"
        with clients_lock:
            clients[conn] = name
        print(f"[JOINED] {name} from {address[0]}:{address[1]}")
        send_json(conn, {"type": "system", "text": f"Welcome, {name}! Type /quit to leave."})
        broadcast({"type": "system", "text": f"{name} joined the chat"}, exclude=conn)

        for line in file:
            try:
                message = json.loads(line)
            except json.JSONDecodeError:
                continue
            if message.get("type") == "chat":
                text = str(message.get("text", "")).strip()
                if not text:
                    continue
                if text.lower() == "/quit":
                    break
                print(f"[{name}] {text}")
                broadcast({"type": "chat", "name": name, "text": text})
    except (OSError, json.JSONDecodeError):
        pass
    finally:
        try:
            file.close()
        except OSError:
            pass
        remove_client(conn)

def main():
    parser = argparse.ArgumentParser(description="MeshChat TCP server")
    parser.add_argument("--host", default="0.0.0.0", help="Interface to listen on (default: all)")
    parser.add_argument("--port", type=int, default=5050)
    args = parser.parse_args()

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((args.host, args.port))
    server.listen()
    print(f"MeshChat server listening on {args.host}:{args.port}")
    print("Keep this window open. Press Ctrl+C to stop.")
    try:
        while True:
            conn, address = server.accept()
            threading.Thread(target=handle_client, args=(conn, address), daemon=True).start()
    except KeyboardInterrupt:
        print("\nStopping MeshChat server...")
    finally:
        server.close()
        with clients_lock:
            active = list(clients)
        for conn in active:
            remove_client(conn)

if __name__ == "__main__":
    main()
