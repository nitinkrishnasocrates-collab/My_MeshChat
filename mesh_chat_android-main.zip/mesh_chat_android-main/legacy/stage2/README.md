# MeshChat

An offline, peer-to-peer messaging system. Devices exchange text messages
without internet, without cellular data, without a central server, and
without a Wi-Fi router — using direct device-to-device transports (starting
with TCP sockets for local development, later Bluetooth and other nearby
transports).

## Status

🚧 **Stage 1 — Environment setup.** Nothing functional yet. This is the
skeleton the rest of the project builds on.

## Planned Architecture

```
UI
 ↓
Application / Messaging
 ↓
Routing (mesh)
 ↓
Peer Management
 ↓
Transport Interface
 ↓
Bluetooth / Wi-Fi Direct / TCP (dev only)
```

## Project Structure

```
MeshChat/
├── client/       # chat client
├── server/       # TCP server (Stage 2+)
├── protocol/     # message format, serialization
├── network/       # node/peer abstractions
├── mesh/         # routing logic
├── bluetooth/    # Bluetooth transport (later stage)
├── database/     # SQLite persistence (store-and-forward)
├── security/     # encryption, key management
├── mobile/       # Android app (later stage)
├── tests/        # unit + integration tests
└── docs/         # architecture notes, diagrams
```

## Setup

```powershell
cd C:\Projects\MeshChat
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python check_env.py
```

## Limitations (will stay true throughout early stages)

- No internet/cloud dependency by design — but early stages use TCP over
  localhost/LAN for learning purposes before Bluetooth is introduced.
- Message range is limited by the transport in use (Bluetooth range,
  physical obstacles, OS background restrictions) — relays extend reach
  only as far as there are intermediate devices.
- No feature is claimed as "done" until it's implemented and tested.

## Roadmap

See the staged build plan we're following — TCP sockets → two-way chat →
message protocol → multi-node → mesh routing → store-and-forward →
Bluetooth → Android → encryption → reliability → testing → polish.


## Run Stage 2 (Windows PowerShell)

Open two PowerShell windows in this `MeshChat` folder.

**Window 1 — start the server:**

```powershell
python .\server\tcp_server.py
```

**Window 2 — connect a client:**

```powershell
python .\client\tcp_client.py --name Nitin
```

Open another PowerShell window and run the client again with another name to test multiple users:

```powershell
python .\client\tcp_client.py --name Friend
```

For two computers on the same Wi-Fi, run the server on one computer. Find its LAN IPv4 address using `ipconfig`, then on the second computer run:

```powershell
python .\client\tcp_client.py --host SERVER_IPV4_ADDRESS --name Friend
```

If Windows Firewall asks, allow Python on **Private networks**. Both computers must be on the same local network. Internet access is not required.

Type `/quit` to leave. Press `Ctrl+C` in the server window to stop the server.

**Current limitations:** This is a central TCP relay for Stage 2 testing, not yet true peer-to-peer mesh networking. Messages are not encrypted, saved, or forwarded while offline. Use only on a trusted private network.
