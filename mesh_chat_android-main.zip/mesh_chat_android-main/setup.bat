@echo off
setlocal
cd /d "%~dp0"
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
if errorlevel 1 (
  echo Python 3.10 or newer was not found. Install it from https://www.python.org/downloads/ and tick "Add python.exe to PATH", then run this again.
  exit /b 1
)
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 18 or newer was not found. Install it from https://nodejs.org/ then run this again.
  exit /b 1
)
call npm install
if errorlevel 1 exit /b 1
echo.
echo Setup finished. Start MeshChat with run.bat
