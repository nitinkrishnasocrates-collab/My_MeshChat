/** Palette: deep teal ink with a sodium-lamp amber for "your" voice, like a node lit on a mesh. */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: { DEFAULT: '#0f1d22', 800: '#15272d', 700: '#1d343c', 600: '#2a444d' },
        fg: { DEFAULT: '#e6edf0', dim: '#8aa3ab' },
        lamp: { DEFAULT: '#f0b44c', ink: '#1c1507' },
        ok: '#5fd4a2',
        bad: '#ef6b5b',
      },
      fontFamily: { sans: ['"Segoe UI Variable Text"', '"Segoe UI"', 'system-ui', 'sans-serif'] },
    },
  },
}
