import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from meshchat import protocol as P  # noqa: E402
from meshchat.db import MIGRATIONS  # noqa: E402
from meshchat.service import MeshChatService, ServiceError  # noqa: E402


def wait_for(cond, timeout=6.0):
    end = time.time() + timeout
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.05)
    return False


def free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class Node:
    """A service instance with its own data dir and a captured event list."""
    def __init__(self, base, name, username):
        self.dir, self.events = os.path.join(base, name), []
        self.open()
        if not self.svc.identity_get():
            self.svc.identity_create(name, username)
        self.me = self.svc.identity_get()

    def open(self):
        self.svc = MeshChatService(self.dir, lambda e, d: self.events.append((e, d)))

    def save_contact(self, other, name=None):
        return self.svc.contacts_add(other.me["id"], name or other.me["display_name"], other.me["username"])

    def messages(self, contact):
        return self.svc.messages_list(contact["id"])


class Base(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.base = self._tmp.name
        self.nodes = []

    def tearDown(self):
        for n in self.nodes:
            try:
                n.svc.close()
            except Exception:
                pass
        self._tmp.cleanup()

    def node(self, name, username):
        n = Node(self.base, name, username)
        self.nodes.append(n)
        return n


class StorageTests(Base):
    def test_identity_contacts_persist_across_restart(self):
        a, b = self.node("alice", "alice_a"), self.node("bob", "bob_b")
        self.assertRegex(a.me["id"], r"^mc_[0-9a-f]{32}$")
        a.save_contact(b)
        a.svc.close()
        a.open()
        self.assertEqual(a.svc.identity_get()["id"], a.me["id"])
        contacts = a.svc.contacts_list()
        self.assertEqual([c["user_id"] for c in contacts], [b.me["id"]])
        self.assertFalse(contacts[0]["online"])  # offline contacts stay saved

    def test_migrations_recorded_and_idempotent(self):
        a = self.node("alice", "alice_a")
        self.assertEqual(a.svc.db.version, len(MIGRATIONS))
        a.svc.close()
        a.open()  # reopening must not re-run or fail
        self.assertEqual(a.svc.db.version, len(MIGRATIONS))

    def test_duplicate_invalid_and_self_contacts_rejected(self):
        a, b = self.node("alice", "alice_a"), self.node("bob", "bob_b")
        a.save_contact(b)
        with self.assertRaisesRegex(ServiceError, "already saved"):
            a.save_contact(b)
        with self.assertRaisesRegex(ServiceError, "Invalid MeshChat ID"):
            a.svc.contacts_add("not-an-id", "X")
        with self.assertRaisesRegex(ServiceError, "own MeshChat ID"):
            a.svc.contacts_add(a.me["id"], "Me")

    def test_edit_favorite_search_delete(self):
        a, b = self.node("alice", "alice_a"), self.node("bob", "bob_b")
        c = a.save_contact(b)
        a.svc.contacts_update(c["id"], {"display_name": "Robert", "favorite": True, "notes": "colleague"})
        self.assertEqual(a.svc.contacts_list("robe")[0]["favorite"], 1)
        self.assertEqual(a.svc.contacts_list("zzz"), [])
        self.assertEqual(len(a.svc.contacts_list("100%")), 0)  # wildcards are escaped
        a.svc.contacts_delete(c["id"])
        self.assertEqual(a.svc.contacts_list(), [])

    def test_export_import_roundtrip(self):
        a, b, c = self.node("alice", "alice_a"), self.node("bob", "bob_b"), self.node("carol", "carol_c")
        a.save_contact(b)
        a.save_contact(c)
        data = json.loads(json.dumps(a.svc.contacts_export()))
        d = self.node("dave", "dave_d")
        self.assertEqual(d.svc.contacts_import(data), {"added": 2, "skipped": 0, "invalid": 0})
        self.assertEqual(d.svc.contacts_import(data), {"added": 0, "skipped": 2, "invalid": 0})
        with self.assertRaises(ServiceError):
            d.svc.contacts_import({"format": "other"})


class ProtocolTests(unittest.TestCase):
    def test_rejects_invalid(self):
        for bad in ("not json", "[]", '{"no_type":1}', "x" * (P.MAX_LINE + 1)):
            with self.assertRaises(P.ProtocolError):
                P.decode(bad)
        ok = {"id": "a" * 32, "to": "mc_" + "b" * 32, "text": "hi"}
        P.validate_dm(ok)
        for patch in ({"id": "short"}, {"to": "nobody"}, {"text": ""}, {"text": "x" * (P.MAX_TEXT + 1)}, {"text": 5}):
            with self.assertRaises(P.ProtocolError):
                P.validate_dm({**ok, **patch})


class NetworkTests(Base):
    def pair(self):
        a, b = self.node("alice", "alice_a"), self.node("bob", "bob_b")
        ca, cb = a.save_contact(b), b.save_contact(a)
        port = free_port()
        a.svc.net_host(port)
        b.svc.net_connect("127.0.0.1", port)
        self.assertTrue(wait_for(lambda: a.svc.net_peers() and b.svc.net_peers()), "peers never saw each other")
        return a, b, ca, cb, port

    def test_message_delivery_history_and_ack(self):
        a, b, ca, cb, _ = self.pair()
        sent = a.svc.messages_send(ca["id"], "hello bob")
        self.assertTrue(wait_for(lambda: a.messages(ca)[0]["status"] == "delivered"))
        got = b.messages(cb)
        self.assertEqual((got[0]["content"], got[0]["status"], got[0]["id"]), ("hello bob", "received", sent["id"]))
        self.assertEqual(b.svc.contacts_list()[0]["unread"], 1)
        b.svc.messages_mark_read(cb["id"])
        self.assertEqual(b.svc.contacts_list()[0]["unread"], 0)
        b.svc.messages_send(cb["id"], "hi alice")
        self.assertTrue(wait_for(lambda: len(a.messages(ca)) == 2))
        # history survives a restart
        b.svc.close()
        b.open()
        self.assertEqual([m["content"] for m in b.messages(cb)], ["hello bob", "hi alice"])

    def test_offline_queue_then_delivery_after_reconnect(self):
        a, b, ca, cb, port = self.pair()
        b.svc.net_disconnect()
        self.assertTrue(wait_for(lambda: not a.svc.net_peers()))
        queued = a.svc.messages_send(ca["id"], "while you were away")
        self.assertEqual(queued["status"], "queued")
        b.svc.net_connect("127.0.0.1", port)
        self.assertTrue(wait_for(lambda: a.messages(ca)[0]["status"] == "delivered"))
        self.assertEqual(b.messages(cb)[0]["content"], "while you were away")

    def test_client_reconnects_after_relay_restart(self):
        a, b, ca, cb, port = self.pair()
        a.svc.net_disconnect()  # relay goes away
        self.assertTrue(wait_for(lambda: b.svc.net_status()["state"] in ("reconnecting", "error")))
        a.svc.net_host(port)  # relay returns on the same port
        self.assertTrue(wait_for(lambda: b.svc.net_status()["state"] == "connected" and b.svc.net_peers()), "no auto-reconnect")

    def test_duplicate_invalid_blocked_and_misaddressed(self):
        a, b, ca, cb, _ = self.pair()
        mid = "c" * 32
        dm = {"type": "dm", "id": mid, "from": a.me["id"], "to": b.me["id"], "text": "once", "ts": time.time()}
        b.svc._on_message(dm)
        b.svc._on_message(dm)  # duplicate
        self.assertEqual(len(b.messages(cb)), 1)
        b.svc._on_message({**dm, "id": "bad"})                       # invalid id
        b.svc._on_message({**dm, "id": "d" * 32, "to": a.me["id"]})  # not addressed to bob
        b.svc._on_message({**dm, "id": "e" * 32, "text": 123})       # invalid text
        self.assertEqual(len(b.messages(cb)), 1)
        b.svc.contacts_update(cb["id"], {"blocked": True})
        b.svc._on_message({**dm, "id": "f" * 32, "text": "blocked"})
        self.assertEqual(len(b.messages(cb)), 1)
        with self.assertRaisesRegex(ServiceError, "blocked"):
            b.svc.messages_send(cb["id"], "x")

    def test_relay_overrides_spoofed_sender(self):
        a, b, ca, cb, port = self.pair()
        mal = self.node("mallory", "mallory_m")
        mal.svc.net_connect("127.0.0.1", port)
        self.assertTrue(wait_for(lambda: mal.svc.net_peers()))
        # mallory claims to be alice; the relay must stamp the real sender
        mal.svc.lan.send({"type": "dm", "id": "9" * 32, "from": a.me["id"], "to": b.me["id"], "text": "spoof", "ts": time.time()})
        self.assertTrue(wait_for(lambda: any(c["user_id"] == mal.me["id"] for c in b.svc.contacts_list())))
        self.assertEqual(b.messages(cb), [])  # nothing attributed to alice

    def test_stage2_legacy_client_still_works(self):
        a = self.node("alice", "alice_a")
        port = free_port()
        a.svc.net_host(port)

        def legacy(name):
            s = socket.create_connection(("127.0.0.1", port), timeout=3)
            s.sendall((json.dumps({"type": "hello", "name": name}) + "\n").encode())
            return s, s.makefile("r", encoding="utf-8")
        s1, f1 = legacy("Nitin")
        s2, f2 = legacy("Friend")
        s2.sendall((json.dumps({"type": "chat", "text": "hello from stage 2"}) + "\n").encode())
        seen = []
        for _ in range(8):
            line = json.loads(f1.readline())
            seen.append(line)
            if line.get("type") == "chat":
                break
        self.assertIn({"type": "chat", "name": "Friend", "text": "hello from stage 2"}, seen)
        s1.close()
        s2.close()

    def test_oversized_line_drops_connection(self):
        a = self.node("alice", "alice_a")
        port = free_port()
        a.svc.net_host(port)
        s = socket.create_connection(("127.0.0.1", port), timeout=3)
        s.sendall(b'{"type":"hello","name":"x"}\n' + b"A" * (P.MAX_LINE + 10) + b"\n")
        s.settimeout(3)
        data = b""
        try:
            while True:
                chunk = s.recv(4096)
                if not chunk:
                    break
                data += chunk
        except socket.timeout:
            self.fail("server did not close the connection")
        s.close()

    def test_port_in_use_gives_friendly_error(self):
        a = self.node("alice", "alice_a")
        with socket.socket() as blocker:
            blocker.bind(("0.0.0.0", 0))
            blocker.listen(1)
            with self.assertRaisesRegex(ServiceError, "Could not listen"):
                a.svc.net_host(blocker.getsockname()[1])


class StdioBridgeTests(unittest.TestCase):
    def test_bridge_roundtrip_and_graceful_exit(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = subprocess.Popen([sys.executable, str(ROOT / "main.py"), "--data-dir", tmp],
                                 stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8")

            def rpc(i, method, params=None):
                p.stdin.write(json.dumps({"id": i, "method": method, "params": params or {}}) + "\n")
                p.stdin.flush()
                while True:
                    msg = json.loads(p.stdout.readline())
                    if msg.get("id") == i:
                        return msg
            self.assertEqual(json.loads(p.stdout.readline())["event"], "backend.ready")
            self.assertIsNone(rpc(1, "identity.get")["result"])
            self.assertIn("error", rpc(2, "identity.create", {"display_name": "", "username": "x"}))
            self.assertIn("error", rpc(3, "nope.nothing"))
            self.assertEqual(rpc(4, "identity.create", {"display_name": "Zoë ✓", "username": "zoe_1"})["result"]["display_name"], "Zoë ✓")
            self.assertTrue(rpc(5, "shutdown")["result"])
            self.assertEqual(p.wait(timeout=5), 0)
            p.stdin.close(); p.stdout.close(); p.stderr.close()

    def test_exits_when_stdin_closes(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = subprocess.Popen([sys.executable, str(ROOT / "main.py"), "--data-dir", tmp], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
            p.stdin.close()
            self.assertEqual(p.wait(timeout=5), 0)
            p.stdout.close()


if __name__ == "__main__":
    unittest.main()
