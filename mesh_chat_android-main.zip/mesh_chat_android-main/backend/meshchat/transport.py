"""Transport interface. LAN/TCP is the only implementation so far."""
from abc import ABC, abstractmethod


class Transport(ABC):
    name = "base"
    encrypted = False

    @abstractmethod
    def start(self, *args, **kwargs) -> None: ...

    @abstractmethod
    def stop(self) -> None: ...

    @abstractmethod
    def send(self, payload: dict) -> bool:
        """Hand a payload to the transport. True means it was written to the link."""
