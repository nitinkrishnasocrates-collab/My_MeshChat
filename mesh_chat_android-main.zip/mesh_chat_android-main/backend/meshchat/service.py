"""MeshChat application service: identity, contacts, messages, networking.

Every public method is exposed to the Electron UI as "<area>.<name>" through
the stdio bridge in main.py. Contacts are keyed by a stable MeshChat ID, never
by IP address.
"""
import json
import secrets
import socket
import sqlite3
import sys
import threading
import time
import uuid
from pathlib import Path

from . import protocol as P
from .db import Database
from .tcp import LanTransport

DEFAULT_PORT = 5050
SETTING_DEFAULTS = {"port": DEFAULT_PORT, "last_host": ""}


class ServiceError(Exception):
    """An error whose message is safe to show to the user."""


def log(msg):
    print(msg, file=sys.stderr, flush=True)


def local_ipv4s():
    ips = []
    try:  # connecting a UDP socket sends nothing; it only picks the LAN interface
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ips.append(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.append(info[4][0])
    except OSError:
        pass
    return [ip for i, ip in enumerate(ips) if ip not in ips[:i] and not ip.startswith(("127.", "0."))]


def _like(q):
    return "%" + q.strip().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"


def _port(value):
    try:
        port = int(value)
    except (TypeError, ValueError):
        raise ServiceError("Port must be a number between 1 and 65535")
    if not 1 <= port <= 65535:
        raise ServiceError("Port must be a number between 1 and 65535")
    return port


class MeshChatService:
    def __init__(self, data_dir, emit):
        Path(data_dir).mkdir(parents=True, exist_ok=True)
        self.emit = emit
        self.db = Database(Path(data_dir) / "meshchat.db")
        self.lan = None
        self._peers = {}
        self._net = {"state": "idle", "role": None, "host": "", "port": DEFAULT_PORT, "detail": ""}
        self._lock = threading.RLock()
        self._closed = False
        self.methods = {
            "identity.get": self.identity_get, "identity.create": self.identity_create,
            "contacts.list": self.contacts_list, "contacts.add": self.contacts_add,
            "contacts.update": self.contacts_update, "contacts.delete": self.contacts_delete,
            "contacts.export": self.contacts_export, "contacts.import": self.contacts_import,
            "messages.list": self.messages_list, "messages.send": self.messages_send,
            "messages.markRead": self.messages_mark_read, "messages.delete": self.messages_delete,
            "net.host": self.net_host, "net.connect": self.net_connect, "net.disconnect": self.net_disconnect,
            "net.status": self.net_status, "net.peers": self.net_peers,
            "settings.get": self.settings_get,
        }

    def call(self, method, params):
        fn = self.methods.get(method)
        if fn is None:
            raise ServiceError(f"Unknown method: {method}")
        try:
            return fn(**(params or {}))
        except TypeError as exc:
            log(f"bad params for {method}: {exc}")
            raise ServiceError(f"Invalid parameters for {method}")

    def close(self):
        self.net_disconnect()
        self._closed = True
        self.db.close()

    # ---------------------------------------------------------------- identity
    def identity_get(self):
        return self.db.one("SELECT * FROM users LIMIT 1")

    def identity_create(self, display_name, username):
        if self.identity_get():
            raise ServiceError("An identity already exists on this device")
        name = P.clean_name(display_name, "")
        username = str(username).strip().lower()
        if not name:
            raise ServiceError("Display name is required")
        if not P.USERNAME_RE.match(username):
            raise ServiceError("Username must be 3-20 characters: a-z, 0-9 or _")
        uid = "mc_" + secrets.token_hex(16)
        self.db.run("INSERT INTO users(id, display_name, username, created_at) VALUES (?,?,?,?)",
                    (uid, name, username, time.time()))
        return self.identity_get()

    def _me(self):
        me = self.identity_get()
        if not me:
            raise ServiceError("Create your profile first")
        return me

    # ---------------------------------------------------------------- contacts
    def _contact(self, cid):
        row = self.db.one("SELECT * FROM contacts WHERE id=?", (cid,))
        if not row:
            raise ServiceError("Contact not found")
        return row

    def contacts_list(self, query=""):
        like = _like(query)
        rows = self.db.all(
            """SELECT c.*, v.id AS conversation_id,
                 (SELECT COUNT(*) FROM messages m WHERE m.conversation_id=v.id AND m.status='received' AND m.is_read=0) AS unread,
                 (SELECT content FROM messages m WHERE m.conversation_id=v.id ORDER BY ts DESC LIMIT 1) AS last_message,
                 (SELECT ts FROM messages m WHERE m.conversation_id=v.id ORDER BY ts DESC LIMIT 1) AS last_ts
               FROM contacts c JOIN conversations v ON v.contact_id=c.id
               WHERE c.display_name LIKE ?1 ESCAPE '\\' OR c.username LIKE ?1 ESCAPE '\\' OR c.user_id LIKE ?1 ESCAPE '\\'
               ORDER BY c.favorite DESC, COALESCE(last_ts, c.added_at) DESC""", (like,))
        with self._lock:
            online = set(self._peers)
        for r in rows:
            r["online"] = r["user_id"] in online
        return rows

    def contacts_add(self, user_id, display_name, username="", host="", port=None, notes=""):
        uid = str(user_id).strip()
        if not P.USER_ID_RE.match(uid):
            raise ServiceError("Invalid MeshChat ID (expected 'mc_' followed by 32 hex characters)")
        me = self.identity_get()
        if me and me["id"] == uid:
            raise ServiceError("That is your own MeshChat ID")
        name = P.clean_name(display_name, "")
        if not name:
            raise ServiceError("Display name is required")
        username = str(username or "").strip().lower()
        if username and not P.USERNAME_RE.match(username):
            raise ServiceError("Username must be 3-20 characters: a-z, 0-9 or _")
        port = _port(port) if port not in (None, "") else None
        now = time.time()
        try:
            with self.db.tx() as cx:
                cur = cx.execute(
                    "INSERT INTO contacts(user_id, display_name, username, host, port, notes, added_at) VALUES (?,?,?,?,?,?,?)",
                    (uid, name, username, str(host or "").strip()[:255], port, str(notes or "")[:500], now))
                cx.execute("INSERT INTO conversations(contact_id, created_at) VALUES (?,?)", (cur.lastrowid, now))
                cid = cur.lastrowid
        except sqlite3.IntegrityError:
            raise ServiceError("This contact is already saved")
        self.emit("contacts.changed", {})
        self._flush(uid)
        return self._contact(cid)

    def contacts_update(self, id, fields):
        row, sets, vals = self._contact(id), [], []
        for key, val in fields.items():
            if key == "display_name":
                val = P.clean_name(val, "")
                if not val:
                    raise ServiceError("Display name is required")
            elif key == "username":
                val = str(val or "").strip().lower()
                if val and not P.USERNAME_RE.match(val):
                    raise ServiceError("Username must be 3-20 characters: a-z, 0-9 or _")
            elif key == "host":
                val = str(val or "").strip()[:255]
            elif key == "port":
                val = _port(val) if val not in (None, "") else None
            elif key == "notes":
                val = str(val or "")[:500]
            elif key in ("favorite", "blocked"):
                val = 1 if val else 0
            else:
                raise ServiceError(f"Field '{key}' cannot be edited")
            sets.append(f"{key}=?")
            vals.append(val)
        if sets:
            self.db.run(f"UPDATE contacts SET {', '.join(sets)} WHERE id=?", (*vals, row["id"]))
            self.emit("contacts.changed", {})
            if "blocked" in fields and not fields["blocked"]:
                self._flush(row["user_id"])
        return self._contact(id)

    def contacts_delete(self, id):
        self._contact(id)
        self.db.run("DELETE FROM contacts WHERE id=?", (id,))  # cascades to conversation and messages
        self.emit("contacts.changed", {})
        return True

    def contacts_export(self):
        rows = self.db.all("SELECT user_id, display_name, username, host, port, notes, favorite FROM contacts ORDER BY display_name")
        return {"format": "meshchat-contacts", "version": 1, "exported_at": time.time(), "contacts": rows}

    def contacts_import(self, data):
        if not isinstance(data, dict) or data.get("format") != "meshchat-contacts" or not isinstance(data.get("contacts"), list):
            raise ServiceError("Not a MeshChat contacts file")
        added = skipped = invalid = 0
        for item in data["contacts"][:5000]:
            try:
                c = self.contacts_add(item["user_id"], item["display_name"], item.get("username", ""),
                                      item.get("host", ""), item.get("port"), item.get("notes", ""))
                if item.get("favorite"):
                    self.contacts_update(c["id"], {"favorite": True})
                added += 1
            except ServiceError as exc:
                skipped += "already saved" in str(exc)
                invalid += "already saved" not in str(exc)
            except (KeyError, TypeError, AttributeError):
                invalid += 1
        return {"added": added, "skipped": skipped, "invalid": invalid}

    # ---------------------------------------------------------------- messages
    def messages_list(self, contact_id, limit=300):
        return self.db.all(
            """SELECT * FROM (SELECT m.* FROM messages m JOIN conversations v ON v.id=m.conversation_id
                 WHERE v.contact_id=? ORDER BY m.ts DESC LIMIT ?) ORDER BY ts ASC""", (contact_id, int(limit)))

    def messages_mark_read(self, contact_id):
        self.db.run("""UPDATE messages SET is_read=1 WHERE is_read=0 AND status='received'
                       AND conversation_id=(SELECT id FROM conversations WHERE contact_id=?)""", (contact_id,))
        self.emit("contacts.changed", {})
        return True

    def messages_delete(self, id):
        self.db.run("DELETE FROM messages WHERE id=?", (id,))
        self.emit("contacts.changed", {})
        return True

    def messages_send(self, contact_id, text):
        me = self._me()
        try:
            text = P.validate_text(text)
        except P.ProtocolError as exc:
            raise ServiceError(f"Cannot send: {exc}")
        contact = self._contact(contact_id)
        if contact["blocked"]:
            raise ServiceError("This contact is blocked. Unblock them to send messages.")
        conv = self.db.one("SELECT id FROM conversations WHERE contact_id=?", (contact_id,))
        msg = {"id": uuid.uuid4().hex, "conversation_id": conv["id"], "sender_id": me["id"],
               "receiver_id": contact["user_id"], "content": text, "ts": time.time(),
               "status": "queued", "transport": "lan", "is_read": 1}
        self.db.run("INSERT INTO messages(id, conversation_id, sender_id, receiver_id, content, ts, status, transport, is_read)"
                    " VALUES (:id,:conversation_id,:sender_id,:receiver_id,:content,:ts,:status,:transport,:is_read)", msg)
        self._transmit(msg)
        self.emit("contacts.changed", {})
        return self.db.one("SELECT * FROM messages WHERE id=?", (msg["id"],))

    def _transmit(self, msg):
        """Send if the recipient is online now. Otherwise the message stays 'queued' until presence says they are back."""
        with self._lock:
            online, lan = msg["receiver_id"] in self._peers, self.lan
        if not (lan and online):
            return
        ok = lan.send({"type": "dm", "id": msg["id"], "to": msg["receiver_id"], "text": msg["content"], "ts": msg["ts"]})
        if ok and self.db.run("UPDATE messages SET status='sent' WHERE id=? AND status='queued'", (msg["id"],)).rowcount:
            self.emit("message.status", {"id": msg["id"], "status": "sent"})

    def _flush(self, uid):
        me = self.identity_get()
        if not me:
            return
        rows = self.db.all(
            """SELECT m.* FROM messages m JOIN conversations v ON v.id=m.conversation_id JOIN contacts c ON c.id=v.contact_id
               WHERE c.user_id=? AND c.blocked=0 AND m.sender_id=? AND m.status IN ('queued','sent') ORDER BY m.ts""", (uid, me["id"]))
        for r in rows:  # 'sent' is retried too: the receiver de-duplicates by message id
            self._transmit(r)

    # ----------------------------------------------------------------- network
    def settings_get(self):
        out = dict(SETTING_DEFAULTS)
        for row in self.db.all("SELECT key, value FROM settings"):
            if row["key"] in out:
                out[row["key"]] = json.loads(row["value"])
        return out

    def _save_setting(self, key, value):
        self.db.run("INSERT INTO settings(key, value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (key, json.dumps(value)))

    def net_host(self, port=DEFAULT_PORT):
        self._start_net("host", "0.0.0.0", _port(port))
        self._save_setting("port", self._net["port"])
        return self.net_status()

    def net_connect(self, host, port=DEFAULT_PORT):
        host = str(host).strip()
        if not host or len(host) > 255 or any(ch.isspace() for ch in host):
            raise ServiceError("Enter the host's IP address, for example 192.168.1.20")
        self._start_net("client", host, _port(port))
        self._save_setting("port", self._net["port"])
        self._save_setting("last_host", host)
        return self.net_status()

    def _start_net(self, role, host, port):
        me = self._me()
        self.net_disconnect()
        hello = {"type": "hello", "v": P.PROTOCOL_VERSION, "name": me["display_name"],
                 "username": me["username"], "user_id": me["id"]}
        lan = LanTransport(self._on_message, self._on_state, log)
        with self._lock:
            self._net.update(state="connecting", role=role, host=host, port=port, detail="")
        try:
            lan.start(role, host, port, hello)
        except OSError as exc:
            with self._lock:
                self._net.update(state="error", detail=f"Could not listen on port {port}: {exc.strerror or exc}. Is another MeshChat or program using it?")
                detail = self._net["detail"]
            self.emit("net.state", self.net_status())
            raise ServiceError(detail)
        self.lan = lan
        self.emit("net.state", self.net_status())

    def net_disconnect(self):
        with self._lock:
            lan, self.lan = self.lan, None
        if lan:
            lan.stop()
        with self._lock:
            was = self._net["state"]
            self._peers.clear()
            self._net.update(state="idle", role=None, detail="")
        if was != "idle" and not self._closed:
            self._record("disconnected")
            self.emit("net.state", self.net_status())
            self.emit("peers", [])
            self.emit("contacts.changed", {})
        return True

    def net_status(self):
        with self._lock:
            s = dict(self._net)
        s.update(transport="lan", encrypted=False, ips=local_ipv4s() if s["role"] == "host" else [])
        return s

    def net_peers(self):
        with self._lock:
            return [{"user_id": k, **v} for k, v in self._peers.items()]

    def _record(self, event):
        self.db.run("INSERT INTO connection_history(ts, transport, host, port, event) VALUES (?,?,?,?,?)",
                    (time.time(), "lan", self._net["host"], self._net["port"], event))

    def _on_state(self, state, detail=""):
        if self._closed:
            return
        with self._lock:
            prev = self._net["state"]
            self._net.update(state=state, detail=detail)
            if state != "connected":
                self._peers.clear()
        if state != prev and "connected" in (prev, state):
            self._record("connected" if state == "connected" else "disconnected")
        self.emit("net.state", self.net_status())
        self.emit("peers", self.net_peers())
        self.emit("contacts.changed", {})

    def _on_message(self, msg):
        if self._closed:
            return
        try:
            kind = msg.get("type")
            if kind == "peers":
                me = self.identity_get()
                peers = {}
                for entry in msg.get("peers") or []:
                    try:
                        info = P.validate_peer(entry)
                    except P.ProtocolError:
                        continue
                    if info["user_id"] != me["id"]:
                        peers[info["user_id"]] = {"name": info["name"], "username": info["username"]}
                with self._lock:
                    self._peers = peers
                self._peers_changed(list(peers))
            elif kind == "presence":
                info = P.validate_peer(msg)
                with self._lock:
                    if msg.get("online") is True:
                        self._peers[info["user_id"]] = {"name": info["name"], "username": info["username"]}
                    else:
                        self._peers.pop(info["user_id"], None)
                if msg.get("online") is not True:
                    self.db.run("UPDATE contacts SET last_seen=? WHERE user_id=?", (time.time(), info["user_id"]))
                self._peers_changed([info["user_id"]] if msg.get("online") is True else [])
            elif kind == "dm":
                self._on_dm(msg)
            elif kind == "ack":
                ack = P.validate_ack(msg)
                sender = msg.get("from")
                if self.db.run("UPDATE messages SET status='delivered' WHERE id=? AND receiver_id=? AND status IN ('queued','sent')",
                               (ack["id"], sender)).rowcount:
                    self.emit("message.status", {"id": ack["id"], "status": "delivered"})
            elif kind == "undelivered":
                mid = msg.get("id")
                if isinstance(mid, str) and self.db.run("UPDATE messages SET status='queued' WHERE id=? AND status='sent'", (mid,)).rowcount:
                    self.emit("message.status", {"id": mid, "status": "queued"})
        except P.ProtocolError as exc:
            log(f"ignored invalid message: {exc}")
        except Exception as exc:  # a bad packet must never kill the network thread
            log(f"error handling {msg.get('type')}: {exc!r}")

    def _peers_changed(self, online_ids):
        now = time.time()
        for uid in online_ids:
            self.db.run("UPDATE contacts SET last_seen=? WHERE user_id=?", (now, uid))
        self.emit("peers", self.net_peers())
        self.emit("contacts.changed", {})
        for uid in online_ids:
            self._flush(uid)

    def _on_dm(self, msg):
        me = self._me()
        dm = P.validate_dm(msg)
        sender = msg.get("from")
        if not (isinstance(sender, str) and P.USER_ID_RE.match(sender)) or dm["to"] != me["id"]:
            raise P.ProtocolError("misaddressed message")
        contact = self.db.one("SELECT * FROM contacts WHERE user_id=?", (sender,))
        if contact is None:  # first message from someone new: save them so the conversation has a home
            with self._lock:
                peer = self._peers.get(sender, {})
            try:
                contact = self.contacts_add(sender, peer.get("name") or "Unknown " + sender[3:9], peer.get("username", ""))
            except ServiceError:
                contact = self.db.one("SELECT * FROM contacts WHERE user_id=?", (sender,))
        if contact is None or contact["blocked"]:
            return  # blocked senders get no ack, so nothing confirms delivery to them
        conv = self.db.one("SELECT id FROM conversations WHERE contact_id=?", (contact["id"],))
        cur = self.db.run(
            "INSERT OR IGNORE INTO messages(id, conversation_id, sender_id, receiver_id, content, ts, status, transport, is_read)"
            " VALUES (?,?,?,?,?,?,'received','lan',0)", (dm["id"], conv["id"], sender, me["id"], dm["text"], dm["ts"]))
        if cur.rowcount:
            row = self.db.one("SELECT * FROM messages WHERE id=?", (dm["id"],))
            self.emit("message.new", {"contact_id": contact["id"], "contact_name": contact["display_name"], "message": row})
        if self.lan:  # always ack, even duplicates, so the sender stops retrying
            self.lan.send({"type": "ack", "id": dm["id"], "to": sender})
