"""LAN transport: the Stage 2 TCP relay and client, extended.

Kept from Stage 2: newline-JSON framing, one thread per client, default port
5050, `hello`/`chat`/`system` messages and the broadcast behaviour of `chat`
(so the original CLI client still works). Added: identity-aware hello, presence,
private routing (`dm`), delivery acks, size limits, and client auto-reconnect.

This is a central relay, not a decentralised mesh.
"""
import os
import socket
import threading

from . import protocol as P
from .transport import Transport

MAX_CONNECTIONS = 64


class _Conn:
    def __init__(self, sock, addr):
        self.sock, self.addr, self.info = sock, addr, None
        self._wlock = threading.Lock()

    def send(self, payload):
        data = P.encode(payload)
        with self._wlock:
            self.sock.sendall(data)

    def close(self):
        for fn in (lambda: self.sock.shutdown(socket.SHUT_RDWR), self.sock.close):
            try:
                fn()
            except OSError:
                pass


class RelayServer:
    def __init__(self, host="0.0.0.0", port=5050, log=lambda m: None):
        self.host, self.port, self.log = host, port, log
        self._srv = None
        self._conns, self._by_id = set(), {}
        self._lock = threading.Lock()
        self._running = False

    def start(self):
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # SO_REUSEADDR on Windows lets another process bind the same port; use the exclusive flag there.
        if os.name == "nt":
            srv.setsockopt(socket.SOL_SOCKET, getattr(socket, "SO_EXCLUSIVEADDRUSE", socket.SO_REUSEADDR), 1)
        else:
            srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            srv.bind((self.host, self.port))
            srv.listen(16)
        except OSError:
            srv.close()
            raise
        srv.settimeout(0.5)
        self.port = srv.getsockname()[1]
        self._srv, self._running = srv, True
        self._accept_thread = threading.Thread(target=self._accept_loop, daemon=True, name="relay-accept")
        self._accept_thread.start()

    def stop(self):
        self._running = False
        t = getattr(self, "_accept_thread", None)
        if t:
            t.join(timeout=2)  # the loop closes the listening socket, so the port is free when stop() returns
        with self._lock:
            conns = list(self._conns)
        for c in conns:
            c.close()

    def _accept_loop(self):
        try:
            while self._running:
                try:
                    sock, addr = self._srv.accept()
                except socket.timeout:
                    continue
                except OSError:
                    break
                with self._lock:
                    full = len(self._conns) >= MAX_CONNECTIONS
                if full:
                    sock.close()
                    continue
                threading.Thread(target=self._handle, args=(sock, addr), daemon=True).start()
        finally:
            self._srv.close()

    def _handle(self, sock, addr):
        conn = _Conn(sock, addr)
        with self._lock:
            self._conns.add(conn)
        f = sock.makefile("r", encoding="utf-8", errors="replace", newline="\n")
        try:
            sock.settimeout(10)  # a client must say hello promptly
            first = f.readline(P.MAX_LINE + 1)
            if not first or len(first) > P.MAX_LINE:
                return
            hello = P.decode(first)
            if hello["type"] != "hello":
                return
            self._register(conn, P.validate_hello(hello))
            sock.settimeout(None)
            while self._running:
                line = f.readline(P.MAX_LINE + 1)
                if not line or len(line) > P.MAX_LINE:
                    break
                try:
                    msg = P.decode(line)
                except P.ProtocolError:
                    continue
                if not self._dispatch(conn, msg):
                    break
        except (OSError, P.ProtocolError):
            pass
        finally:
            self._drop(conn)
            try:
                f.close()
            except OSError:
                pass

    def _register(self, conn, info):
        conn.info = info
        uid = info["user_id"]
        old = None
        with self._lock:
            if uid:
                old = self._by_id.get(uid)
                self._by_id[uid] = conn
            peers = [c.info for c in self._by_id.values() if c is not conn]
        if old and old is not conn:
            old.close()  # same identity reconnecting replaces the stale link
        self.log(f"[JOINED] {info['name']} from {conn.addr[0]}:{conn.addr[1]}")
        conn.send({"type": "system", "text": f"Welcome, {info['name']}! Type /quit to leave."})
        if uid:
            conn.send({"type": "peers", "peers": peers})
            self._broadcast({"type": "presence", "online": True, **info}, exclude=conn)
        self._broadcast({"type": "system", "text": f"{info['name']} joined the chat"}, exclude=conn)

    def _drop(self, conn):
        uid = conn.info["user_id"] if conn.info else None
        current = False
        with self._lock:
            self._conns.discard(conn)
            if uid and self._by_id.get(uid) is conn:
                del self._by_id[uid]
                current = True
        conn.close()
        if conn.info:
            self.log(f"[LEFT] {conn.info['name']}")
            if current:
                self._broadcast({"type": "presence", "online": False, **conn.info})
            self._broadcast({"type": "system", "text": f"{conn.info['name']} left the chat"})

    def _broadcast(self, payload, exclude=None):
        with self._lock:
            targets = [c for c in self._conns if c.info and c is not exclude]
        for c in targets:
            try:
                c.send(payload)
            except OSError:
                c.close()

    def _forward(self, conn, target_id, payload, undelivered_id=None):
        with self._lock:
            target = self._by_id.get(target_id)
        try:
            if target is None:
                raise OSError("offline")
            target.send(payload)
        except OSError:
            if undelivered_id:
                try:
                    conn.send({"type": "undelivered", "id": undelivered_id, "to": target_id})
                except OSError:
                    pass

    def _dispatch(self, conn, msg):
        info, kind = conn.info, msg["type"]
        try:
            if kind == "chat":  # Stage 2 broadcast chat, kept for the legacy CLI client
                text = P.validate_text(msg.get("text"))
                if text.lower() == "/quit":
                    return False
                self.log(f"[{info['name']}] {text}")
                self._broadcast({"type": "chat", "name": info["name"], "text": text})
            elif kind == "dm" and info["user_id"]:
                dm = P.validate_dm(msg)
                # `from` is set here from the registered identity, never taken from the client.
                self._forward(conn, dm["to"], {"type": "dm", "id": dm["id"], "from": info["user_id"],
                                               "to": dm["to"], "text": dm["text"], "ts": dm["ts"]}, dm["id"])
            elif kind == "ack" and info["user_id"]:
                ack = P.validate_ack(msg)
                self._forward(conn, ack["to"], {"type": "ack", "id": ack["id"], "from": info["user_id"], "to": ack["to"]})
        except P.ProtocolError as exc:
            self.log(f"[DROP] bad message from {info['name']}: {exc}")
        return True


class TcpClient:
    def __init__(self, host, port, hello, on_message, on_state, auto_reconnect=True):
        self.host, self.port, self.hello = host, port, hello
        self.on_message, self.on_state, self.auto_reconnect = on_message, on_state, auto_reconnect
        self._stop = threading.Event()
        self._sock = None
        self._wlock = threading.Lock()
        self._thread = None

    def start(self):
        self._thread = threading.Thread(target=self._run, daemon=True, name="tcp-client")
        self._thread.start()

    def stop(self):
        self._stop.set()
        s = self._sock
        if s:
            try:
                s.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            s.close()
        if self._thread and self._thread is not threading.current_thread():
            self._thread.join(timeout=2)

    def send(self, payload) -> bool:
        s = self._sock
        if s is None:
            return False
        try:
            with self._wlock:
                s.sendall(P.encode(payload))
            return True
        except OSError:
            return False

    def _state(self, state, detail=""):
        if not self._stop.is_set():
            self.on_state(state, detail)

    def _run(self):
        delay, first = 1, True
        while not self._stop.is_set():
            self._state("connecting" if first else "reconnecting")
            first = False
            try:
                sock = socket.create_connection((self.host, self.port), timeout=5)
            except OSError as exc:
                self._state("error", f"Could not reach {self.host}:{self.port} ({exc.strerror or exc})")
                if not self.auto_reconnect or self._stop.wait(delay):
                    return
                delay = min(delay * 2, 15)
                continue
            sock.settimeout(None)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            self._sock = sock
            try:
                sock.sendall(P.encode(self.hello))
                self._state("connected")
                delay = 1
                f = sock.makefile("r", encoding="utf-8", errors="replace", newline="\n")
                while True:
                    line = f.readline(P.MAX_LINE + 1)
                    if not line or len(line) > P.MAX_LINE:
                        break
                    try:
                        msg = P.decode(line)
                    except P.ProtocolError:
                        continue
                    self.on_message(msg)
            except OSError:
                pass
            finally:
                self._sock = None
                try:
                    sock.close()
                except OSError:
                    pass
            if self._stop.is_set():
                return
            self._state("reconnecting" if self.auto_reconnect else "disconnected", "Connection lost")
            if not self.auto_reconnect or self._stop.wait(delay):
                return


class LanTransport(Transport):
    """Hosts the relay (role 'host') and/or connects a client to one."""
    name, encrypted = "lan", False

    def __init__(self, on_message, on_state, log=lambda m: None):
        self.on_message, self.on_state, self.log = on_message, on_state, log
        self.relay = self.client = None

    def start(self, role, host, port, hello, auto_reconnect=True):
        if role == "host":
            self.relay = RelayServer("0.0.0.0", port, self.log)
            self.relay.start()
            host, port = "127.0.0.1", self.relay.port
        self.client = TcpClient(host, port, hello, self.on_message, self.on_state, auto_reconnect)
        self.client.start()

    def stop(self):
        if self.client:
            self.client.stop()
        if self.relay:
            self.relay.stop()
        self.client = self.relay = None

    def send(self, payload) -> bool:
        return bool(self.client and self.client.send(payload))
