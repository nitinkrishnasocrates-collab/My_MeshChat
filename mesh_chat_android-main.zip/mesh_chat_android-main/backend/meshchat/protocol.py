"""MeshChat wire protocol: newline-delimited UTF-8 JSON.

Framing and the hello/chat/system message types are unchanged from Stage 2, so
the original CLI client still works against the new relay. Added in this
version: identity in `hello`, `peers`/`presence`, `dm`, `ack`, `undelivered`.
"""
import json
import re
import time

PROTOCOL_VERSION = 1
MAX_LINE = 64 * 1024
MAX_TEXT = 4000
MAX_NAME = 24
USER_ID_RE = re.compile(r"^mc_[0-9a-f]{32}$")
MSG_ID_RE = re.compile(r"^[0-9a-f]{32}$")
USERNAME_RE = re.compile(r"^[a-z0-9_]{3,20}$")


class ProtocolError(ValueError):
    """Malformed or oversized protocol data."""


def encode(payload: dict) -> bytes:
    return (json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")


def decode(line: str) -> dict:
    if len(line) > MAX_LINE:
        raise ProtocolError("line too long")
    try:
        obj = json.loads(line)
    except json.JSONDecodeError as exc:
        raise ProtocolError("invalid JSON") from exc
    if not isinstance(obj, dict) or not isinstance(obj.get("type"), str):
        raise ProtocolError("message needs a string 'type'")
    return obj


def clean_name(value, default="Guest") -> str:
    text = "".join(ch for ch in str(value or "") if ch.isprintable()).strip()
    return text[:MAX_NAME] or default


def validate_text(text) -> str:
    if not isinstance(text, str):
        raise ProtocolError("text must be a string")
    text = text.strip()
    if not text:
        raise ProtocolError("empty message")
    if len(text) > MAX_TEXT:
        raise ProtocolError("message too long")
    return text


def validate_hello(msg: dict) -> dict:
    uid = msg.get("user_id")
    if uid is not None and not (isinstance(uid, str) and USER_ID_RE.match(uid)):
        raise ProtocolError("bad user_id")
    username = msg.get("username") or ""
    if username and not (isinstance(username, str) and USERNAME_RE.match(username)):
        raise ProtocolError("bad username")
    return {"user_id": uid, "name": clean_name(msg.get("name")), "username": username}


def _id(value, rx, what):
    if not (isinstance(value, str) and rx.match(value)):
        raise ProtocolError(f"bad {what}")
    return value


def validate_dm(msg: dict) -> dict:
    ts = msg.get("ts")
    now = time.time()
    ok_ts = isinstance(ts, (int, float)) and not isinstance(ts, bool) and 0 < ts < now + 86400
    return {
        "id": _id(msg.get("id"), MSG_ID_RE, "message id"),
        "to": _id(msg.get("to"), USER_ID_RE, "recipient"),
        "text": validate_text(msg.get("text")),
        "ts": float(ts) if ok_ts else now,
    }


def validate_ack(msg: dict) -> dict:
    return {"id": _id(msg.get("id"), MSG_ID_RE, "message id"), "to": _id(msg.get("to"), USER_ID_RE, "recipient")}


def validate_peer(entry) -> dict:
    if not isinstance(entry, dict):
        raise ProtocolError("bad peer")
    info = validate_hello({"user_id": entry.get("user_id"), "name": entry.get("name"), "username": entry.get("username")})
    if not info["user_id"]:
        raise ProtocolError("peer without id")
    return info
