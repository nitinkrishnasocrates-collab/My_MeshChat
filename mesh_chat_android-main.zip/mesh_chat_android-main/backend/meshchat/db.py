"""SQLite layer with versioned, transactional migrations (PRAGMA user_version)."""
import sqlite3
import threading
from contextlib import contextmanager

MIGRATIONS = [
    # v1
    """
    CREATE TABLE users(
      id TEXT PRIMARY KEY, display_name TEXT NOT NULL, username TEXT NOT NULL UNIQUE, created_at REAL NOT NULL);
    CREATE TABLE contacts(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL UNIQUE,
      display_name TEXT NOT NULL,
      username TEXT NOT NULL DEFAULT '',
      host TEXT NOT NULL DEFAULT '',
      port INTEGER,
      notes TEXT NOT NULL DEFAULT '',
      favorite INTEGER NOT NULL DEFAULT 0,
      blocked INTEGER NOT NULL DEFAULT 0,
      added_at REAL NOT NULL,
      last_seen REAL);
    CREATE TABLE conversations(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      contact_id INTEGER NOT NULL UNIQUE REFERENCES contacts(id) ON DELETE CASCADE,
      created_at REAL NOT NULL);
    CREATE TABLE messages(
      id TEXT PRIMARY KEY,
      conversation_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
      sender_id TEXT NOT NULL,
      receiver_id TEXT NOT NULL,
      content TEXT NOT NULL,
      ts REAL NOT NULL,
      status TEXT NOT NULL CHECK(status IN ('queued','sent','delivered','received')),
      transport TEXT NOT NULL DEFAULT 'lan',
      is_read INTEGER NOT NULL DEFAULT 0);
    CREATE INDEX idx_messages_conv_ts ON messages(conversation_id, ts);
    CREATE INDEX idx_messages_pending ON messages(receiver_id, status);
    CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE connection_history(
      id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL NOT NULL, transport TEXT NOT NULL,
      host TEXT, port INTEGER, event TEXT NOT NULL);
    """,
]


class Database:
    def __init__(self, path):
        self._lock = threading.RLock()
        self.conn = sqlite3.connect(str(path), check_same_thread=False, isolation_level=None)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys=ON")
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA busy_timeout=5000")
        self._migrate()

    @property
    def version(self) -> int:
        return self.conn.execute("PRAGMA user_version").fetchone()[0]

    def _migrate(self):
        current = self.version
        if current > len(MIGRATIONS):
            raise RuntimeError("This database was created by a newer MeshChat; refusing to open it.")
        for target, sql in enumerate(MIGRATIONS, start=1):
            if target <= current:
                continue
            try:  # DDL and the version bump commit together or not at all
                self.conn.executescript(f"BEGIN;\n{sql}\nPRAGMA user_version={target};\nCOMMIT;")
            except sqlite3.Error:
                if self.conn.in_transaction:
                    self.conn.execute("ROLLBACK")
                raise

    def all(self, sql, args=()):
        with self._lock:
            return [dict(r) for r in self.conn.execute(sql, args).fetchall()]

    def one(self, sql, args=()):
        with self._lock:
            row = self.conn.execute(sql, args).fetchone()
            return dict(row) if row else None

    def run(self, sql, args=()):
        with self._lock:
            return self.conn.execute(sql, args)

    @contextmanager
    def tx(self):
        with self._lock:
            self.conn.execute("BEGIN IMMEDIATE")
            try:
                yield self.conn
                self.conn.execute("COMMIT")
            except BaseException:
                self.conn.execute("ROLLBACK")
                raise

    def close(self):
        with self._lock:
            self.conn.close()
