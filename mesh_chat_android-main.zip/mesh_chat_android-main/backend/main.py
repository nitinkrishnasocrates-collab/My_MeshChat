"""MeshChat backend. Talks to Electron over stdio: one JSON object per line.

  request : {"id": 1, "method": "contacts.list", "params": {...}}
  response: {"id": 1, "result": ...} or {"id": 1, "error": "message"}
  event   : {"event": "message.new", "data": {...}}

No network port is opened for the UI. The process exits when stdin closes, so it
cannot outlive the app.
"""
import argparse
import json
import sys
import threading
import traceback

from meshchat import __version__
from meshchat.service import MeshChatService, ServiceError


def main():
    ap = argparse.ArgumentParser(description="MeshChat backend")
    ap.add_argument("--data-dir", required=True)
    args = ap.parse_args()
    sys.stdin.reconfigure(encoding="utf-8")
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

    out_lock = threading.Lock()

    def write(obj):
        line = json.dumps(obj, ensure_ascii=False, default=str)
        with out_lock:
            sys.stdout.write(line + "\n")
            sys.stdout.flush()

    svc = MeshChatService(args.data_dir, lambda event, data: write({"event": event, "data": data}))
    try:
        write({"event": "backend.ready", "data": {"version": __version__}})
        for line in sys.stdin:
            if not line.strip():
                continue
            try:
                req = json.loads(line)
                rid, method = req.get("id"), req["method"]
            except (ValueError, KeyError, AttributeError):
                continue
            if method == "shutdown":
                write({"id": rid, "result": True})
                break
            try:
                write({"id": rid, "result": svc.call(method, req.get("params"))})
            except ServiceError as exc:
                write({"id": rid, "error": str(exc)})
            except Exception:
                traceback.print_exc(file=sys.stderr)
                write({"id": rid, "error": "Internal error. See the log for details."})
    finally:
        svc.close()


if __name__ == "__main__":
    main()
