﻿'use strict'
// Electron main process: owns the window and the Python backend's lifecycle.
const { app, BrowserWindow, ipcMain } = require('electron')
const { spawn } = require('node:child_process')
const path = require('node:path')
const readline = require('node:readline')

let win = null
let backend = null
let quitting = false
let nextId = 1
const pending = new Map()

function backendCommand() {
  const dataDir = app.getPath('userData')
  if (app.isPackaged) {
    const exe = process.platform === 'win32' ? 'meshchat-backend.exe' : 'meshchat-backend'
    return { cmd: path.join(process.resourcesPath, 'backend', exe), args: ['--data-dir', dataDir] }
  }
  const py = process.env.MESHCHAT_PYTHON || (process.platform === 'win32' ? 'python' : 'python3')
  return { cmd: py, args: [path.join(__dirname, '..', 'backend', 'main.py'), '--data-dir', dataDir] }
}

function emit(msg) {
  if (win && !win.isDestroyed()) win.webContents.send('mc:event', msg)
}

function rejectAll(reason) {
  for (const p of pending.values()) p.reject(new Error(reason))
  pending.clear()
}

function startBackend() {
  const { cmd, args } = backendCommand()
  const child = spawn(cmd, args, {
    stdio: ['pipe', 'pipe', 'pipe'],
    windowsHide: true,
    env: { ...process.env, PYTHONUTF8: '1', PYTHONUNBUFFERED: '1' },
  })
  backend = child
  child.stdin.on('error', () => {})
  readline.createInterface({ input: child.stdout }).on('line', (line) => {
    let msg
    try { msg = JSON.parse(line) } catch { return }
    if (msg.event) return emit(msg)
    const p = pending.get(msg.id)
    if (!p) return
    pending.delete(msg.id)
    if (msg.error) p.reject(new Error(msg.error)); else p.resolve(msg.result)
  })
  child.stderr.on('data', (d) => console.error('[backend]', d.toString().trimEnd()))
  child.on('error', (err) => {
    if (backend === child) backend = null
    rejectAll('Backend failed to start')
    emit({ event: 'backend.crashed', data: { message: `Could not start the backend (${cmd}): ${err.message}` } })
  })
  child.on('exit', (code) => {
    if (backend !== child) return
    backend = null
    rejectAll('Backend stopped')
    if (!quitting) emit({ event: 'backend.crashed', data: { message: `The backend stopped unexpectedly (exit code ${code}).` } })
  })
}

function call(method, params) {
  return new Promise((resolve, reject) => {
    if (!backend) return reject(new Error('The backend is not running'))
    const id = nextId++
    pending.set(id, { resolve, reject })
    backend.stdin.write(JSON.stringify({ id, method, params: params || {} }) + '\n')
  })
}

function stopBackend() {
  const child = backend
  if (!child) return Promise.resolve()
  return new Promise((resolve) => {
    const timer = setTimeout(() => child.kill(), 3000) // last resort; normally it exits on its own
    child.once('exit', () => { clearTimeout(timer); resolve() })
    try {
      child.stdin.write(JSON.stringify({ id: 0, method: 'shutdown' }) + '\n')
      child.stdin.end()
    } catch { child.kill() }
  })
}

ipcMain.handle('mc:call', (_e, method, params) => {
  if (typeof method !== 'string') throw new Error('Invalid method')
  return call(method, params)
})
ipcMain.handle('mc:restart', async () => { await stopBackend(); startBackend() })

function createWindow() {
  win = new BrowserWindow({
    width: 1280, height: 800, minWidth: 900, minHeight: 560,
    backgroundColor: '#0f1d22', title: 'MeshChat', autoHideMenuBar: true,
    icon: path.join(__dirname, 'assets', 'meshchat.ico'),
    icon: path.join(__dirname, 'assets', 'meshchat.ico'),
    webPreferences: { preload: path.join(__dirname, 'preload.cjs'), contextIsolation: true, nodeIntegration: false, sandbox: true },
  })
  win.loadFile(path.join(__dirname, '..', 'dist', 'index.html'))
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }))
  win.webContents.on('will-navigate', (e) => e.preventDefault())
}

app.setAppUserModelId('com.meshchat.desktop')
app.whenReady().then(() => { startBackend(); createWindow() })
app.on('window-all-closed', () => app.quit())
app.on('before-quit', (e) => {
  if (quitting || !backend) return
  e.preventDefault()
  quitting = true
  stopBackend().finally(() => app.quit())
})


