'use strict'
const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('mc', {
  call: (method, params) => ipcRenderer.invoke('mc:call', method, params),
  restart: () => ipcRenderer.invoke('mc:restart'),
  onEvent: (cb) => {
    const handler = (_e, msg) => cb(msg)
    ipcRenderer.on('mc:event', handler)
    return () => ipcRenderer.removeListener('mc:event', handler)
  },
})
