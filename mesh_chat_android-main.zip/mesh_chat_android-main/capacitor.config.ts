import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.meshchat.mobile',
  appName: 'MeshChat',
  webDir: 'dist'
};

export default config;
