@echo off
setlocal
cd /d "%~dp0"
call setup.bat
if errorlevel 1 exit /b 1
python -m pip install -r requirements-build.txt
if errorlevel 1 exit /b 1
call npm run dist
if errorlevel 1 exit /b 1
echo.
echo Done. The installer is in the release folder.
