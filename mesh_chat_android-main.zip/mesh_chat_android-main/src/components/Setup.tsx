import { useState } from 'react'
import { Radio } from 'lucide-react'
import { api, type User } from '../bridge'
import { inputCls, primaryBtn } from './ui'

export default function Setup({ onDone }: { onDone: (u: User) => void }) {
  const [name, setName] = useState('')
  const [username, setUsername] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setBusy(true)
    setError('')
    try { onDone(await api.createIdentity(name, username)) }
    catch (x) { setError((x as Error).message) }
    finally { setBusy(false) }
  }

  return (
    <div className="grid h-full place-items-center bg-ink-800">
      <form onSubmit={submit} className="w-[26rem] space-y-5 rounded-xl bg-ink p-8 shadow-xl border border-ink-600">
        <div className="flex items-center gap-3">
          <Radio className="text-lamp" size={28} />
          <h1 className="text-2xl font-semibold">Welcome to MeshChat</h1>
        </div>
        <p className="text-sm leading-relaxed text-fg-dim">
          Create your identity. It is generated and stored on this device only: no email, phone number or internet account.
        </p>
        <label className="block space-y-1 text-sm">Display name
          <input className={inputCls} value={name} maxLength={24} onChange={(e) => setName(e.target.value)} autoFocus />
        </label>
        <label className="block space-y-1 text-sm">Username
          <input className={inputCls} value={username} placeholder="letters, numbers, _" maxLength={20}
            onChange={(e) => setUsername(e.target.value.toLowerCase())} />
        </label>
        {error && <p role="alert" className="text-sm text-bad">{error}</p>}
        <button className={`${primaryBtn} w-full`} disabled={busy || !name.trim() || !username}>Create identity</button>
      </form>
    </div>
  )
}
