import { useEffect, useState } from 'react'
import { Plug, Server, Unplug } from 'lucide-react'
import { api, type NetStatus } from '../bridge'
import { ghostBtn, inputCls, primaryBtn } from './ui'

function describe(n: NetStatus) {
  switch (n.state) {
    case 'idle': return 'Not connected'
    case 'connecting': return n.role === 'host' ? 'Starting…' : `Connecting to ${n.host}:${n.port}…`
    case 'connected': return n.role === 'host' ? `Hosting on port ${n.port}` : `Connected to ${n.host}:${n.port}`
    case 'reconnecting': return 'Connection lost. Reconnecting…'
    case 'error': return n.detail || 'Connection error'
    default: return 'Disconnected'
  }
}

export default function ConnectionCard({ net, onError }: { net: NetStatus | null; onError: (m: string) => void }) {
  const [mode, setMode] = useState<'host' | 'join' | null>(null)
  const [host, setHost] = useState('')
  const [port, setPort] = useState('5050')
  useEffect(() => { api.settings().then((s) => { setPort(String(s.port)); setHost(s.last_host) }).catch(() => {}) }, [])

  if (!net) return null
  const active = ['connecting', 'connected', 'reconnecting', 'error'].includes(net.state)
  const dot = net.state === 'connected' ? 'bg-ok' : net.state === 'error' ? 'bg-bad' : active ? 'bg-lamp' : 'bg-fg-dim'

  async function start() {
    try {
      if (mode === 'host') await api.host(Number(port))
      else await api.connect(host, Number(port))
      setMode(null)
    } catch (e) { onError((e as Error).message) }
  }

  return (
    <div className="space-y-2 rounded-lg bg-ink p-3 text-sm border border-ink-600">
      <div className="flex items-start gap-2">
        <span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${dot}`} />
        <div className="min-w-0">
          <p className="break-words">{describe(net)}</p>
          <p className="text-xs text-fg-dim">Local Wi-Fi/LAN, not encrypted</p>
          {net.state === 'connected' && net.role === 'host' && net.ips.length > 0 && (
            <p className="mt-1 text-xs">Friends join at <span className="font-medium text-lamp">{net.ips[0]}:{net.port}</span></p>
          )}
        </div>
      </div>
      {active ? (
        <button className={`${ghostBtn} w-full`} onClick={() => api.disconnect().catch((e) => onError(e.message))}>
          <Unplug size={15} /> Disconnect
        </button>
      ) : mode ? (
        <div className="space-y-2">
          {mode === 'join' && <input className={inputCls} placeholder="Host IP, e.g. 192.168.1.20" value={host} onChange={(e) => setHost(e.target.value)} autoFocus />}
          <input className={inputCls} inputMode="numeric" placeholder="Port" value={port} onChange={(e) => setPort(e.target.value)} />
          <div className="flex gap-2">
            <button className={`${primaryBtn} flex-1`} onClick={start} disabled={mode === 'join' && !host.trim()}>{mode === 'host' ? 'Start hosting' : 'Connect'}</button>
            <button className={ghostBtn} onClick={() => setMode(null)}>Cancel</button>
          </div>
        </div>
      ) : (
        <div className="flex gap-2">
          <button className={`${ghostBtn} flex-1`} onClick={() => setMode('host')}><Server size={15} /> Host</button>
          <button className={`${ghostBtn} flex-1`} onClick={() => setMode('join')}><Plug size={15} /> Join</button>
        </div>
      )}
    </div>
  )
}
