import { Check, CheckCheck, Clock } from 'lucide-react'
import type { Contact, Status } from '../bridge'

export function Avatar({ name, id, size = 40 }: { name: string; id: string; size?: number }) {
  let hue = 0
  for (const ch of id) hue = (hue * 31 + ch.charCodeAt(0)) % 360
  return (
    <div className="grid shrink-0 place-items-center rounded-full font-semibold text-ink"
      style={{ width: size, height: size, background: `hsl(${hue} 38% 70%)`, fontSize: size * 0.4 }}>
      {name.trim().charAt(0).toUpperCase() || '?'}
    </div>
  )
}

export function StatusTick({ status }: { status: Status }) {
  const label = { queued: 'Waiting for the recipient to come online', sent: 'Sent', delivered: 'Delivered', received: '' }[status]
  if (status === 'received') return null
  const Icon = status === 'queued' ? Clock : status === 'sent' ? Check : CheckCheck
  return <span title={label} aria-label={label}><Icon size={13} /></span>
}

export const fmtTime = (ts: number) => new Date(ts * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
export const fmtDate = (ts: number) => new Date(ts * 1000).toLocaleDateString([], { day: 'numeric', month: 'short', year: 'numeric' })

export function presence(c: Contact) {
  if (c.online) return 'Online'
  return c.last_seen ? `Last seen ${fmtDate(c.last_seen)}, ${fmtTime(c.last_seen)}` : 'Offline'
}

export const inputCls = 'w-full rounded-md bg-ink px-3 py-2 text-sm text-fg placeholder:text-fg-dim border border-ink-600 focus:border-lamp'
export const btnCls = 'inline-flex items-center justify-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors disabled:opacity-50'
export const primaryBtn = `${btnCls} bg-lamp text-lamp-ink hover:bg-[#f6c36d]`
export const ghostBtn = `${btnCls} bg-ink-700 text-fg hover:bg-ink-600`
