import { useEffect, useState } from 'react'
import { Ban, Star, Trash2 } from 'lucide-react'
import { api, type Contact } from '../bridge'
import { Avatar, fmtDate, ghostBtn, inputCls, presence, primaryBtn } from './ui'

interface Props { contact: Contact; onChanged: () => void; onDeleted: () => void; onError: (m: string) => void; onInfo: (m: string) => void }

export default function InfoPanel({ contact: c, onChanged, onDeleted, onError, onInfo }: Props) {
  const [name, setName] = useState(c.display_name)
  const [notes, setNotes] = useState(c.notes)
  const [confirm, setConfirm] = useState(false)
  useEffect(() => { setName(c.display_name); setNotes(c.notes); setConfirm(false) }, [c.id, c.display_name, c.notes])

  const update = (fields: Parameters<typeof api.updateContact>[1], msg?: string) =>
    api.updateContact(c.id, fields).then(() => { onChanged(); if (msg) onInfo(msg) }).catch((e) => onError(e.message))
  const dirty = name !== c.display_name || notes !== c.notes

  return (
    <aside className="flex h-full w-72 shrink-0 flex-col gap-4 overflow-y-auto border-l border-ink-600 bg-ink-800 p-4">
      <div className="flex flex-col items-center gap-2 pt-2">
        <Avatar name={c.display_name} id={c.user_id} size={72} />
        <p className="text-lg font-semibold">{c.display_name}</p>
        <p className={`text-sm ${c.online ? 'text-ok' : 'text-fg-dim'}`}>{presence(c)}</p>
      </div>

      <dl className="space-y-3 text-sm">
        <div><dt className="text-fg-dim">Username</dt><dd>{c.username ? `@${c.username}` : 'Not set'}</dd></div>
        <div><dt className="text-fg-dim">MeshChat ID</dt><dd className="break-all font-mono text-xs">{c.user_id}</dd></div>
        <div><dt className="text-fg-dim">Connection</dt><dd>Local Wi-Fi/LAN relay, not encrypted</dd></div>
        <div><dt className="text-fg-dim">Added</dt><dd>{fmtDate(c.added_at)}</dd></div>
      </dl>

      <label className="block space-y-1 text-sm">Display name
        <input className={inputCls} value={name} maxLength={24} onChange={(e) => setName(e.target.value)} />
      </label>
      <label className="block space-y-1 text-sm">Notes
        <textarea className={`${inputCls} h-20 resize-none`} value={notes} maxLength={500} onChange={(e) => setNotes(e.target.value)} />
      </label>
      <button className={primaryBtn} disabled={!dirty || !name.trim()} onClick={() => update({ display_name: name, notes }, 'Contact updated')}>Save changes</button>

      <div className="mt-auto space-y-2">
        <button className={`${ghostBtn} w-full`} onClick={() => update({ favorite: !c.favorite })}>
          <Star size={15} className={c.favorite ? 'fill-lamp text-lamp' : ''} /> {c.favorite ? 'Remove from favorites' : 'Add to favorites'}
        </button>
        <button className={`${ghostBtn} w-full`} onClick={() => update({ blocked: !c.blocked }, c.blocked ? 'Contact unblocked' : 'Contact blocked')}>
          <Ban size={15} /> {c.blocked ? 'Unblock contact' : 'Block contact'}
        </button>
        <button className={`${ghostBtn} w-full text-bad`} onClick={() => confirm
          ? api.deleteContact(c.id).then(() => { onDeleted(); onChanged() }).catch((e) => onError(e.message))
          : setConfirm(true)}>
          <Trash2 size={15} /> {confirm ? 'Click again to delete contact and chat' : 'Remove contact'}
        </button>
      </div>
    </aside>
  )
}
