import { useRef, useState } from 'react'
import { Ban, Check, Copy, Download, Search, Star, Upload, UserPlus } from 'lucide-react'
import { api, type Contact, type NetStatus, type Peer, type User } from '../bridge'
import AddContact from './AddContact'
import ConnectionCard from './ConnectionCard'
import { Avatar, fmtTime, ghostBtn, inputCls } from './ui'

interface Props {
  me: User; contacts: Contact[]; peers: Peer[]; net: NetStatus | null; selectedId: number | null
  onSelect: (id: number) => void; onChanged: () => void; onError: (m: string) => void; onInfo: (m: string) => void
}

export default function Sidebar({ me, contacts, peers, net, selectedId, onSelect, onChanged, onError, onInfo }: Props) {
  const [query, setQuery] = useState('')
  const [adding, setAdding] = useState(false)
  const [copied, setCopied] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  const q = query.trim().toLowerCase()
  const shown = q ? contacts.filter((c) => [c.display_name, c.username, c.user_id].some((v) => v.toLowerCase().includes(q))) : contacts
  const nearby = peers.filter((p) => !contacts.some((c) => c.user_id === p.user_id))

  async function copyId() {
    await navigator.clipboard.writeText(me.id)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  async function exportContacts() {
    try {
      const data = await api.exportContacts()
      const a = document.createElement('a')
      a.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }))
      a.download = 'meshchat-contacts.json'
      a.click()
      URL.revokeObjectURL(a.href)
    } catch (e) { onError((e as Error).message) }
  }

  async function importContacts(file: File) {
    try {
      const r = await api.importContacts(JSON.parse(await file.text()))
      onInfo(`Imported ${r.added} contact(s). Skipped ${r.skipped} already saved${r.invalid ? `, ${r.invalid} invalid` : ''}.`)
      onChanged()
    } catch (e) { onError(e instanceof SyntaxError ? 'That file is not valid JSON' : (e as Error).message) }
  }

  return (
    <aside className="flex h-full w-80 shrink-0 flex-col gap-3 border-r border-ink-600 bg-ink-800 p-3">
      <div className="flex items-center gap-3 px-1">
        <Avatar name={me.display_name} id={me.id} />
        <div className="min-w-0 flex-1">
          <p className="truncate font-semibold">{me.display_name}</p>
          <p className="truncate text-xs text-fg-dim">@{me.username}</p>
        </div>
        <button className="rounded p-2 text-fg-dim hover:bg-ink-700 hover:text-fg" onClick={copyId} title="Copy my MeshChat ID" aria-label="Copy my MeshChat ID">
          {copied ? <Check size={16} className="text-ok" /> : <Copy size={16} />}
        </button>
      </div>

      <ConnectionCard net={net} onError={onError} />

      {nearby.length > 0 && (
        <div className="space-y-1 rounded-lg border border-ink-600 p-2 text-sm">
          <p className="px-1 text-xs text-fg-dim">On this network, not in your contacts</p>
          {nearby.map((p) => (
            <div key={p.user_id} className="flex items-center gap-2 px-1">
              <span className="min-w-0 flex-1 truncate">{p.name}</span>
              <button className={`${ghostBtn} !px-2 !py-1 text-xs`} onClick={() =>
                api.addContact({ user_id: p.user_id, display_name: p.name, username: p.username }).then((c) => onSelect(c.id)).catch((e) => onError(e.message))}>
                <UserPlus size={13} /> Add
              </button>
            </div>
          ))}
        </div>
      )}

      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search size={15} className="absolute left-3 top-2.5 text-fg-dim" />
          <input className={`${inputCls} pl-9`} placeholder="Search contacts" value={query} onChange={(e) => setQuery(e.target.value)} />
        </div>
        <button className={ghostBtn} onClick={() => setAdding(true)} title="Add contact" aria-label="Add contact"><UserPlus size={16} /></button>
      </div>

      <ul className="-mx-1 min-h-0 flex-1 overflow-y-auto">
        {shown.length === 0 && (
          <li className="px-3 py-6 text-center text-sm text-fg-dim">
            {contacts.length === 0 ? 'No contacts yet. Add one with their MeshChat ID, or connect to a network and add someone nearby.' : 'No contacts match your search.'}
          </li>
        )}
        {shown.map((c) => (
          <li key={c.id}>
            <button onClick={() => onSelect(c.id)} aria-current={c.id === selectedId}
              className={`flex w-full items-center gap-3 rounded-lg px-2 py-2 text-left ${c.id === selectedId ? 'bg-ink-700' : 'hover:bg-ink-700/60'}`}>
              <div className="relative">
                <Avatar name={c.display_name} id={c.user_id} />
                <span className={`absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-ink-800 ${c.online ? 'bg-ok' : 'bg-fg-dim'}`} title={c.online ? 'Online' : 'Offline'} />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1">
                  <span className="truncate font-medium">{c.display_name}</span>
                  {c.favorite ? <Star size={12} className="shrink-0 fill-lamp text-lamp" /> : null}
                  {c.blocked ? <Ban size={12} className="shrink-0 text-bad" /> : null}
                  {c.last_ts && <span className="ml-auto shrink-0 text-xs text-fg-dim">{fmtTime(c.last_ts)}</span>}
                </div>
                <div className="flex items-center gap-2">
                  <span className="truncate text-sm text-fg-dim">{c.last_message ?? `@${c.username || 'no-username'}`}</span>
                  {c.unread > 0 && <span className="ml-auto shrink-0 rounded-full bg-lamp px-1.5 text-xs font-semibold text-lamp-ink">{c.unread}</span>}
                </div>
              </div>
            </button>
          </li>
        ))}
      </ul>

      <div className="flex gap-2">
        <button className={`${ghostBtn} flex-1 text-xs`} onClick={() => fileRef.current?.click()}><Upload size={14} /> Import</button>
        <button className={`${ghostBtn} flex-1 text-xs`} onClick={exportContacts} disabled={contacts.length === 0}><Download size={14} /> Export</button>
        <input ref={fileRef} type="file" accept=".json,application/json" hidden
          onChange={(e) => { const f = e.target.files?.[0]; if (f) importContacts(f); e.target.value = '' }} />
      </div>

      {adding && <AddContact onClose={() => setAdding(false)} onAdded={(id) => { setAdding(false); onSelect(id); onChanged() }} />}
    </aside>
  )
}
