import { useState } from 'react'
import { X } from 'lucide-react'
import { api } from '../bridge'
import { ghostBtn, inputCls, primaryBtn } from './ui'

export default function AddContact({ onClose, onAdded }: { onClose: () => void; onAdded: (id: number) => void }) {
  const [f, setF] = useState({ user_id: '', display_name: '', username: '', notes: '' })
  const [error, setError] = useState('')
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value })

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    try { onAdded((await api.addContact({ ...f, user_id: f.user_id.trim() })).id) }
    catch (x) { setError((x as Error).message) }
  }

  return (
    <div className="fixed inset-0 z-20 grid place-items-center bg-black/50" role="dialog" aria-modal="true" aria-label="Add contact">
      <form onSubmit={submit} className="w-[26rem] space-y-4 rounded-xl border border-ink-600 bg-ink-800 p-6 shadow-xl">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Add contact</h2>
          <button type="button" className="text-fg-dim hover:text-fg" onClick={onClose} aria-label="Close"><X size={18} /></button>
        </div>
        <p className="text-sm text-fg-dim">Ask your friend for the MeshChat ID shown under their name. It stays the same even when their IP address changes.</p>
        <label className="block space-y-1 text-sm">MeshChat ID
          <input className={inputCls} value={f.user_id} onChange={set('user_id')} placeholder="mc_…" autoFocus />
        </label>
        <label className="block space-y-1 text-sm">Display name
          <input className={inputCls} value={f.display_name} onChange={set('display_name')} maxLength={24} />
        </label>
        <label className="block space-y-1 text-sm">Username (optional)
          <input className={inputCls} value={f.username} onChange={set('username')} maxLength={20} />
        </label>
        <label className="block space-y-1 text-sm">Notes (optional)
          <input className={inputCls} value={f.notes} onChange={set('notes')} maxLength={500} />
        </label>
        {error && <p role="alert" className="text-sm text-bad">{error}</p>}
        <div className="flex justify-end gap-2">
          <button type="button" className={ghostBtn} onClick={onClose}>Cancel</button>
          <button className={primaryBtn} disabled={!f.user_id.trim() || !f.display_name.trim()}>Save contact</button>
        </div>
      </form>
    </div>
  )
}
