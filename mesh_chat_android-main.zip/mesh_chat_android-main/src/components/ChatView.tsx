import { useEffect, useRef, useState } from 'react'
import { Copy, Info, Send, Trash2 } from 'lucide-react'
import type { Contact, Message, NetStatus } from '../bridge'
import { Avatar, fmtTime, presence, primaryBtn, StatusTick } from './ui'

interface Props {
  contact: Contact; messages: Message[]; net: NetStatus | null; showInfo: boolean
  onToggleInfo: () => void; onSend: (text: string) => Promise<void>; onDelete: (id: string) => void; onCopied: () => void
}

export default function ChatView({ contact, messages, net, showInfo, onToggleInfo, onSend, onDelete, onCopied }: Props) {
  const [text, setText] = useState('')
  const bottom = useRef<HTMLDivElement>(null)
  useEffect(() => { bottom.current?.scrollIntoView({ block: 'end' }) }, [messages.length, contact.id])

  const connected = net?.state === 'connected'
  const route = contact.blocked ? 'Blocked' : contact.online && connected ? 'Delivering over local Wi-Fi/LAN, not encrypted'
    : 'Offline. New messages wait here and send when they reconnect.'

  async function submit() {
    const t = text.trim()
    if (!t) return
    setText('')
    await onSend(t)
  }

  return (
    <section className="flex min-w-0 flex-1 flex-col">
      <header className="flex items-center gap-3 border-b border-ink-600 bg-ink-800 px-4 py-3">
        <Avatar name={contact.display_name} id={contact.user_id} />
        <div className="min-w-0 flex-1">
          <h2 className="truncate font-semibold">{contact.display_name}</h2>
          <p className={`truncate text-xs ${contact.online ? 'text-ok' : 'text-fg-dim'}`}>{presence(contact)}</p>
        </div>
        <button onClick={onToggleInfo} aria-pressed={showInfo} title="Contact info" aria-label="Contact info"
          className={`rounded p-2 hover:bg-ink-700 ${showInfo ? 'text-lamp' : 'text-fg-dim'}`}><Info size={18} /></button>
      </header>

      <div className="flex-1 space-y-1 overflow-y-auto px-6 py-4">
        {messages.length === 0 && <p className="py-10 text-center text-sm text-fg-dim">No messages yet. Say hello.</p>}
        {messages.map((m) => {
          const mine = m.status !== 'received'
          return (
            <div key={m.id} className={`group flex items-center gap-1 ${mine ? 'flex-row-reverse' : ''}`}>
              <div className={`max-w-[70%] rounded-2xl px-3.5 py-2 ${mine ? 'rounded-br-sm bg-lamp text-lamp-ink' : 'rounded-bl-sm bg-ink-700'}`}>
                <p className="whitespace-pre-wrap break-words text-[0.95rem] leading-snug">{m.content}</p>
                <p className={`mt-1 flex items-center justify-end gap-1 text-[0.7rem] ${mine ? 'text-lamp-ink/70' : 'text-fg-dim'}`}>
                  {fmtTime(m.ts)} {mine && <StatusTick status={m.status} />}
                </p>
              </div>
              <div className="flex opacity-0 transition-opacity group-hover:opacity-100 focus-within:opacity-100">
                <button className="rounded p-1.5 text-fg-dim hover:text-fg" title="Copy" aria-label="Copy message"
                  onClick={() => navigator.clipboard.writeText(m.content).then(onCopied)}><Copy size={14} /></button>
                <button className="rounded p-1.5 text-fg-dim hover:text-bad" title="Delete on this device" aria-label="Delete message"
                  onClick={() => onDelete(m.id)}><Trash2 size={14} /></button>
              </div>
            </div>
          )
        })}
        <div ref={bottom} />
      </div>

      <footer className="border-t border-ink-600 bg-ink-800 px-4 py-3">
        <p className="mb-2 text-xs text-fg-dim">{route}</p>
        <div className="flex items-end gap-2">
          <textarea rows={1} value={text} maxLength={4000} disabled={!!contact.blocked} placeholder="Type a message"
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void submit() } }}
            className="max-h-32 min-h-[2.5rem] flex-1 resize-none rounded-md border border-ink-600 bg-ink px-3 py-2 text-sm placeholder:text-fg-dim focus:border-lamp" />
          <button className={primaryBtn} onClick={() => void submit()} disabled={!text.trim() || !!contact.blocked} aria-label="Send"><Send size={16} /></button>
        </div>
      </footer>
    </section>
  )
}
