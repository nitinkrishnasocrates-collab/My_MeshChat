// Typed wrapper over the preload bridge (window.mc) that talks to the Python backend.
export type Status = 'queued' | 'sent' | 'delivered' | 'received'

export interface User { id: string; display_name: string; username: string }
export interface Contact {
  id: number; user_id: string; display_name: string; username: string; host: string; port: number | null
  notes: string; favorite: number; blocked: number; added_at: number; last_seen: number | null
  online: boolean; unread: number; last_message: string | null; last_ts: number | null
}
export interface Message {
  id: string; conversation_id: number; sender_id: string; receiver_id: string; content: string
  ts: number; status: Status; transport: string; is_read: number
}
export interface Peer { user_id: string; name: string; username: string }
export interface NetStatus {
  state: 'idle' | 'connecting' | 'connected' | 'reconnecting' | 'error' | 'disconnected'
  role: 'host' | 'client' | null; host: string; port: number; transport: 'lan'; encrypted: false; detail: string; ips: string[]
}
export interface McEvent { event: string; data: any }
export type NewContact = { user_id: string; display_name: string; username?: string; notes?: string }
export type EditableContact = Partial<Pick<Contact, 'display_name' | 'username' | 'host' | 'port' | 'notes'>> & { favorite?: boolean; blocked?: boolean }

declare global {
  interface Window {
    mc: {
      call(method: string, params?: object): Promise<unknown>
      restart(): Promise<void>
      onEvent(cb: (e: McEvent) => void): () => void
    }
  }
}

async function call<T>(method: string, params: object = {}): Promise<T> {
  try {
    return (await window.mc.call(method, params)) as T
  } catch (e) {
    // Electron prefixes remote errors with "Error invoking remote method ..."; show only the real message.
    throw new Error(String((e as Error).message).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''))
  }
}

export const api = {
  identity: () => call<User | null>('identity.get'),
  createIdentity: (display_name: string, username: string) => call<User>('identity.create', { display_name, username }),
  contacts: (query = '') => call<Contact[]>('contacts.list', { query }),
  addContact: (c: NewContact) => call<Contact>('contacts.add', c),
  updateContact: (id: number, fields: EditableContact) => call<Contact>('contacts.update', { id, fields }),
  deleteContact: (id: number) => call<boolean>('contacts.delete', { id }),
  exportContacts: () => call<object>('contacts.export'),
  importContacts: (data: unknown) => call<{ added: number; skipped: number; invalid: number }>('contacts.import', { data }),
  messages: (contact_id: number) => call<Message[]>('messages.list', { contact_id }),
  send: (contact_id: number, text: string) => call<Message>('messages.send', { contact_id, text }),
  markRead: (contact_id: number) => call<boolean>('messages.markRead', { contact_id }),
  deleteMessage: (id: string) => call<boolean>('messages.delete', { id }),
  netStatus: () => call<NetStatus>('net.status'),
  peers: () => call<Peer[]>('net.peers'),
  host: (port: number) => call<NetStatus>('net.host', { port }),
  connect: (host: string, port: number) => call<NetStatus>('net.connect', { host, port }),
  disconnect: () => call<boolean>('net.disconnect'),
  settings: () => call<{ port: number; last_host: string }>('settings.get'),
}
