import { useCallback, useEffect, useRef, useState } from 'react'
import { Radio } from 'lucide-react'
import { api, type Contact, type Message, type NetStatus, type Peer, type User } from './bridge'
import ChatView from './components/ChatView'
import InfoPanel from './components/InfoPanel'
import Setup from './components/Setup'
import Sidebar from './components/Sidebar'
import { ghostBtn } from './components/ui'

export default function App() {
  const [me, setMe] = useState<User | null | undefined>(undefined)
  const [contacts, setContacts] = useState<Contact[]>([])
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [net, setNet] = useState<NetStatus | null>(null)
  const [peers, setPeers] = useState<Peer[]>([])
  const [toast, setToast] = useState<{ text: string; error: boolean } | null>(null)
  const [crashed, setCrashed] = useState<string | null>(null)
  const [showInfo, setShowInfo] = useState(true)
  const selected = useRef<number | null>(null)
  selected.current = selectedId
  const timer = useRef<number | undefined>(undefined)

  const say = useCallback((text: string, error = false) => {
    setToast({ text, error })
    window.clearTimeout(timer.current)
    timer.current = window.setTimeout(() => setToast(null), 5000)
  }, [])
  const fail = useCallback((m: string) => say(m, true), [say])
  const reload = useCallback(() => { api.contacts().then(setContacts).catch((e) => fail(e.message)) }, [fail])

  useEffect(() => {
    const off = window.mc.onEvent(({ event, data }) => {
      if (event === 'contacts.changed') reload()
      else if (event === 'net.state') setNet(data)
      else if (event === 'peers') setPeers(data)
      else if (event === 'backend.crashed') setCrashed(data.message)
      else if (event === 'message.status') setMessages((ms) => ms.map((m) => (m.id === data.id ? { ...m, status: data.status } : m)))
      else if (event === 'message.new') {
        const open = selected.current === data.contact_id
        if (open) {
          setMessages((ms) => (ms.some((m) => m.id === data.message.id) ? ms : [...ms, data.message]))
          if (document.hasFocus()) api.markRead(data.contact_id).catch(() => {})
        }
        if (!open || !document.hasFocus()) {
          try { new Notification(data.contact_name, { body: data.message.content }) } catch { /* notifications unavailable */ }
        }
      }
    })
    api.identity().then(setMe).catch((e) => setCrashed(e.message))
    return off
  }, [reload])

  useEffect(() => {
    if (!me) return
    reload()
    api.netStatus().then(setNet).catch(() => {})
    api.peers().then(setPeers).catch(() => {})
  }, [me, reload])

  useEffect(() => {
    if (selectedId === null) { setMessages([]); return }
    api.messages(selectedId).then(setMessages).catch((e) => fail(e.message))
    api.markRead(selectedId).catch(() => {})
    const onFocus = () => api.markRead(selectedId).catch(() => {})
    window.addEventListener('focus', onFocus)
    return () => window.removeEventListener('focus', onFocus)
  }, [selectedId, fail])

  useEffect(() => {
    if (selectedId !== null && contacts.length && !contacts.some((c) => c.id === selectedId)) setSelectedId(null)
  }, [contacts, selectedId])

  const contact = contacts.find((c) => c.id === selectedId) ?? null

  async function send(text: string) {
    if (selectedId === null) return
    try { const m = await api.send(selectedId, text); setMessages((ms) => [...ms, m]) }
    catch (e) { fail((e as Error).message) }
  }

  if (crashed) {
    return (
      <div className="grid h-full place-items-center">
        <div className="max-w-md space-y-4 text-center">
          <h1 className="text-xl font-semibold">MeshChat's backend stopped</h1>
          <p className="text-sm text-fg-dim">{crashed}</p>
          <button className={ghostBtn} onClick={() => { setCrashed(null); window.mc.restart().then(() => api.identity().then(setMe)).catch((e) => setCrashed(e.message)) }}>Restart backend</button>
        </div>
      </div>
    )
  }
  if (me === undefined) return <div className="grid h-full place-items-center text-fg-dim">Starting…</div>
  if (me === null) return <Setup onDone={setMe} />

  return (
    <div className="flex h-full">
      <Sidebar me={me} contacts={contacts} peers={peers} net={net} selectedId={selectedId}
        onSelect={setSelectedId} onChanged={reload} onError={fail} onInfo={say} />
      {contact ? (
        <>
          <ChatView contact={contact} messages={messages} net={net} showInfo={showInfo} onToggleInfo={() => setShowInfo((s) => !s)}
            onSend={send} onCopied={() => say('Copied')}
            onDelete={(id) => api.deleteMessage(id).then(() => setMessages((ms) => ms.filter((m) => m.id !== id))).catch((e) => fail(e.message))} />
          {showInfo && <InfoPanel contact={contact} onChanged={reload} onDeleted={() => setSelectedId(null)} onError={fail} onInfo={say} />}
        </>
      ) : (
        <div className="grid flex-1 place-items-center px-8 text-center">
          <div className="max-w-sm space-y-3">
            <Radio className="mx-auto text-lamp" size={36} />
            <h1 className="text-xl font-semibold">Pick a contact to start chatting</h1>
            <p className="text-sm leading-relaxed text-fg-dim">
              Messages and contacts live on this device. To chat, one person hosts and the others join over the same Wi-Fi or LAN. No internet is needed.
            </p>
          </div>
        </div>
      )}
      {toast && (
        <div role="status" className={`fixed bottom-4 right-4 z-30 max-w-sm rounded-lg px-4 py-3 text-sm shadow-lg ${toast.error ? 'bg-bad text-white' : 'bg-ink-600 text-fg'}`}>
          {toast.text}
        </div>
      )}
    </div>
  )
}
