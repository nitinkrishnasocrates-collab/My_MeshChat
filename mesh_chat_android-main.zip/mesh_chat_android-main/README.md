# MeshChat Desktop

Offline-first desktop messenger: Electron + React + TypeScript + Tailwind UI, Python backend, SQLite storage.
Messages travel over your **local Wi-Fi/LAN**; no internet, cloud or account is needed.

## What this version is (and is not)

Inspecting the two uploaded projects showed:

- **Stage 1** is only a skeleton: empty folders (`.gitkeep`), a README and `check_env.py`. It contains **no Bluetooth or mesh code**.
- **Stage 2** has a ~100-line threaded TCP relay (`server/tcp_server.py`) and a CLI client (`client/tcp_client.py`) on port 5050 that broadcast chat to everyone.

So this version is built on Stage 2. Its framing, port and `hello`/`chat`/`system` messages are kept, and the original CLI client still works against the new relay (tested). Both originals are untouched in `legacy/`.

| Area | Status |
|---|---|
| First-run profile (display name, username, generated MeshChat ID) | Done, tested |
| Permanent contacts in SQLite: add, search, edit, favorite, block, delete, JSON import/export, duplicate prevention | Done, tested |
| 1:1 messaging over LAN: history, timestamps, sent/delivered ticks, unread counts, copy, delete, desktop notifications | Done, tested |
| Offline queue: messages to an offline contact wait and send when that contact reconnects | Done, tested (sender-side; see limits) |
| Host/Join connection manager, auto-reconnect, friendly errors, LAN IP shown for hosts | Done, tested |
| Backend started and stopped by Electron; no orphan Python processes | Done, tested |
| Bluetooth (Stage 1 has no code), true P2P mesh, groups, file sharing, QR codes, profile pictures | **Not built** |
| Encryption and authentication | **Not built.** The UI says "not encrypted" wherever it matters |
| Light/System theme, message search UI, typing indicators, emoji picker | Not built |

## Run (Windows 10/11, PowerShell)

Needs Python 3.10+ and Node.js 18+ on PATH.

```powershell
cd MeshChat-Desktop
.\setup.bat      # checks Python/Node, runs npm install
.\run.bat        # builds the UI and starts the app (the backend starts by itself)
```

**Two apps on one PC** (separate data folders):

```powershell
npm run build:ui
npx electron . "--user-data-dir=$env:TEMP\mc-alice"
npx electron . "--user-data-dir=$env:TEMP\mc-bob"
```
In one app click **Host**, in the other **Join** with `127.0.0.1`. Each app lists the other under "On this network"; click **Add**, then chat.

**Two PCs on the same Wi-Fi:** one clicks **Host** and reads out the address shown ("Friends join at 192.168.x.x:5050"); the other clicks **Join** and enters it. Allow MeshChat/Python on **Private networks** when Windows Firewall asks. The router does not need internet.

## Build the installer

```powershell
.\build.bat        # or: python -m pip install -r requirements-build.txt; npm run dist
```
This freezes the backend with PyInstaller (so users need no Python), builds the UI, and runs electron-builder (NSIS). Output: `release\MeshChat Setup 0.1.0.exe`.
If electron-builder fails with a symbolic-link error on Windows, run PowerShell as Administrator or enable Developer Mode.

## Tests

```powershell
npm run test:backend     # 16 backend tests: storage, migrations, protocol, TCP, queue, reconnect, spoofing, legacy client, stdio bridge
npm run typecheck
node tests/e2e/two_apps.mjs   # Linux + xvfb only: drives two real Electron apps through the UI
```

## Layout

```
electron/        main.cjs (window + backend lifecycle), preload.cjs (the only bridge: window.mc)
src/             React UI: App.tsx, bridge.ts (typed API), components/
backend/
  main.py        stdio JSON bridge to Electron (no network port for the UI)
  meshchat/      protocol.py  db.py (migrations)  service.py  transport.py  tcp.py (relay + client + LanTransport)
  tests/
legacy/          untouched Stage 1 and Stage 2
tests/e2e/       two-app UI test
setup.bat  run.bat  build.bat  requirements*.txt  package.json (electron-builder config under "build")
```

## Design notes

- **Bridge:** Electron talks to Python over stdin/stdout JSON lines, so there is no local HTTP/WebSocket port to expose. The backend exits when its stdin closes, so it cannot outlive the app.
- **Identity:** `mc_` + 128 random bits, generated once. Contacts are keyed by this ID, never by IP.
- **Protocol:** newline-delimited JSON, 64 KB line limit, 4000-character messages, validated IDs. The relay stamps the real sender on every `dm` and drops spoofed `from` fields.
- **Transports:** `Transport` is a small interface; `LanTransport` is the only implementation. Bluetooth or a real mesh would be new transports behind it.
- **Database:** `PRAGMA user_version` migrations applied transactionally. Tables: users, contacts, conversations, messages, settings, connection_history.

## Known limits

- This is a **central relay** (the host), not a decentralised mesh. Messages cannot hop through other peers.
- **No encryption or authentication.** Anyone on the LAN who can reach the host can join, and the host could read or forge messages. Use trusted networks only.
- Offline delivery needs the **sender's app running** when the recipient returns. Nothing is stored on the relay.
- A first message from an unknown ID auto-saves that sender as a contact (block them in the info panel).
- Removing a contact deletes that conversation's messages. Message deletion is local only.
- Windows installer, Windows Firewall behaviour and file import/export dialogs have not been exercised on Windows (see the summary).
- Bluetooth would need a new transport; Python's `socket.AF_BLUETOOTH` (RFCOMM) or the `bleak` BLE library are the options to evaluate. Neither has been tried.
