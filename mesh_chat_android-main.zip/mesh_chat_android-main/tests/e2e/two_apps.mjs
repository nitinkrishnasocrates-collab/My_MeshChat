// Dev-only end-to-end test (Linux + xvfb): drives two real Electron apps through the UI over CDP.
// Usage: npm run build:ui && node tests/e2e/two_apps.mjs
import { spawn, execSync } from 'node:child_process'
import fs from 'node:fs'

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const ROOT = decodeURIComponent(new URL('../..', import.meta.url).pathname).replace(/\/$/, '')
const out = (m) => console.log(m)

class App {
  constructor(name, port) { this.name = name; this.port = port; this.id = 0; this.pend = new Map() }
  async start() {
    const dir = `/tmp/mc-smoke-${this.name}`
    fs.rmSync(dir, { recursive: true, force: true })
    this.proc = spawn('xvfb-run', ['-a', '-s', '-screen 0 1400x900x24', `${ROOT}/node_modules/electron/dist/electron`, ROOT,
      '--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage', `--remote-debugging-port=${this.port}`, `--user-data-dir=${dir}`],
      { detached: true, stdio: ['ignore', 'pipe', 'pipe'] })
    this.log = ''
    this.proc.stderr.on('data', (d) => (this.log += d))
    this.proc.stdout.on('data', (d) => (this.log += d))
    let target
    for (let i = 0; i < 60 && !target; i++) {
      await sleep(500)
      try { target = (await (await fetch(`http://127.0.0.1:${this.port}/json`)).json()).find((t) => t.type === 'page') } catch {}
    }
    if (!target) throw new Error(`${this.name}: no page target\n${this.log}`)
    this.ws = new WebSocket(target.webSocketDebuggerUrl)
    await new Promise((r) => (this.ws.onopen = r))
    this.ws.onmessage = (e) => { const m = JSON.parse(e.data); const p = this.pend.get(m.id); if (p) { this.pend.delete(m.id); m.error ? p.rej(new Error(JSON.stringify(m.error))) : p.res(m.result) } }
    await this.send('Page.enable')
  }
  send(method, params = {}) { const id = ++this.id; this.ws.send(JSON.stringify({ id, method, params })); return new Promise((res, rej) => this.pend.set(id, { res, rej })) }
  async eval(expr) { const r = await this.send('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true }); if (r.exceptionDetails) throw new Error(r.exceptionDetails.text + ' ' + JSON.stringify(r.exceptionDetails.exception?.description)); return r.result.value }
  text() { return this.eval('document.body.innerText') }
  async waitText(s, ms = 12000) { const end = Date.now() + ms; while (Date.now() < end) { if ((await this.text()).includes(s)) return true; await sleep(250) } throw new Error(`${this.name}: timed out waiting for "${s}". Page:\n${await this.text()}\n--log--\n${this.log.slice(-1500)}`) }
  click(label, scope = 'button') { return this.eval(`(()=>{const b=[...document.querySelectorAll('${scope}')].find(e=>e.innerText.trim()===${JSON.stringify(label)}||e.getAttribute('aria-label')===${JSON.stringify(label)});if(!b)throw new Error('no button '+${JSON.stringify(label)});b.click();return true})()`) }
  type(placeholderOrLabel, value) { return this.eval(`(()=>{const els=[...document.querySelectorAll('input,textarea')];const el=els.find(e=>e.placeholder===${JSON.stringify(placeholderOrLabel)}||(e.closest('label')?.firstChild?.textContent||'').trim()===${JSON.stringify(placeholderOrLabel)});if(!el)throw new Error('no input '+${JSON.stringify(placeholderOrLabel)});const proto=el.tagName==='TEXTAREA'?HTMLTextAreaElement:HTMLInputElement;Object.getOwnPropertyDescriptor(proto.prototype,'value').set.call(el,${JSON.stringify(value)});el.dispatchEvent(new Event('input',{bubbles:true}));return true})()`) }
  async shot(file) { const r = await this.send('Page.captureScreenshot', { format: 'png' }); fs.writeFileSync(`/tmp/${file}`, Buffer.from(r.data, 'base64')) }
  async close() { try { await Promise.race([this.eval('window.close()'), sleep(1500)]) } catch {} out(`  (${this.name} window closed)`) }
}

const results = []
const check = (name, ok) => { results.push([name, ok]); out(`${ok ? 'PASS' : 'FAIL'}  ${name}`) }

const A = new App('alice', 9331), B = new App('bob', 9332)
try {
  await Promise.all([A.start(), B.start()])
  await A.waitText('Welcome to MeshChat'); await B.waitText('Welcome to MeshChat')
  check('first launch shows setup screen (both apps, backend answered identity.get)', true)
  await A.shot('01-setup.png')

  for (const [app, name, user] of [[A, 'Alice', 'alice_a'], [B, 'Bob', 'bob_b']]) {
    await app.type('Display name', name); await app.type('Username', user); await app.click('Create identity')
    await app.waitText('Not connected')
  }
  check('identity created through the UI; main screen loads', true)

  await A.click('Host'); await A.type('Port', '5151'); await A.click('Start hosting'); await A.waitText('Hosting on port 5151')
  await B.click('Join'); await B.type('Host IP, e.g. 192.168.1.20', '127.0.0.1'); await B.type('Port', '5151'); await B.click('Connect')
  await B.waitText('Connected to 127.0.0.1:5151')
  check('A hosts on 5151, B joins over TCP', true)

  await A.waitText('On this network'); await B.waitText('On this network')
  check('each app discovers the other through relay presence', true)
  await A.shot('02-nearby.png')

  await A.click('Add'); await B.click('Add')
  await A.waitText('Contact info'.length ? '@bob_b' : ''); await B.waitText('@alice_a')
  check('contacts saved from nearby peers (stable MeshChat IDs)', true)

  await A.type('Type a message', 'hello Bob, over LAN with no internet')
  await A.click('Send')
  await B.waitText('hello Bob, over LAN with no internet', 8000)
  check('message sent from A appears in B', true)
  const delivered = await (async () => { const end = Date.now() + 6000; while (Date.now() < end) { if (await A.eval(`!!document.querySelector('[aria-label="Delivered"]')`)) return true; await sleep(200) } return false })()
  check('A shows the delivered tick (ack round-trip)', delivered)

  await B.type('Type a message', 'got it Alice ✓')
  await B.click('Send')
  await A.waitText('got it Alice ✓', 8000)
  check('reply from B appears in A', true)
  await A.shot('03-chat-A.png'); await B.shot('04-chat-B.png')

  // restart B: contacts + history must survive, backend must come back by itself
  const pyCount = (filter = '') => execSync(`ps -eo args | grep -E '^python3? .*backend/main.py' | grep -c -- '${filter}' || true`).toString().trim()
  const pidsBefore = pyCount('')
  out(`backend processes running with two apps open: ${pidsBefore}`)
  check('exactly one Python backend per app', pidsBefore === '2')
  await B.close(); await sleep(2500)
  const left = pyCount('mc-smoke-bob')
  check('closing app B leaves no Python backend behind', left === '0')
  const B2 = new App('bob', 9333)
  // reuse same data dir: start without wiping
  fs.mkdirSync('/tmp/mc-smoke-bob', { recursive: true })
  B2.start = async function () { const proc = spawn('xvfb-run', ['-a', '-s', '-screen 0 1400x900x24', `${ROOT}/node_modules/electron/dist/electron`, ROOT, '--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage', `--remote-debugging-port=9333`, `--user-data-dir=/tmp/mc-smoke-bob`], { detached: true, stdio: 'ignore' }); this.proc = proc; let target; for (let i = 0; i < 60 && !target; i++) { await sleep(500); try { target = (await (await fetch('http://127.0.0.1:9333/json')).json()).find((t) => t.type === 'page') } catch {} } this.ws = new WebSocket(target.webSocketDebuggerUrl); await new Promise((r) => (this.ws.onopen = r)); this.ws.onmessage = (e) => { const m = JSON.parse(e.data); const p = this.pend.get(m.id); if (p) { this.pend.delete(m.id); m.error ? p.rej(new Error(JSON.stringify(m.error))) : p.res(m.result) } }; await this.send('Page.enable') }
  await B2.start()
  await B2.waitText('Alice')
  await B2.eval(`[...document.querySelectorAll('li button')].find(b=>b.innerText.includes('Alice')).click()`)
  await B2.waitText('hello Bob, over LAN with no internet')
  check('after restart B still has identity, contact and message history (no setup screen)', !(await B2.text()).includes('Welcome to MeshChat'))
  await B2.shot('05-after-restart.png')
  await B2.close(); await A.close(); await sleep(2500)
  const leftover = pyCount('')
  check('all Python backends gone after both apps closed', leftover === '0')
} catch (e) {
  out('ERROR: ' + e.message)
  results.push(['run', false])
} finally {
  for (const a of [A, B]) { try { process.kill(-a.proc.pid, 'SIGKILL') } catch {} }
  execSync(`pkill -f '[b]ackend/main.py' || true; pkill -f '[e]lectron/dist' || true; pkill Xvfb || true`)
  out(`\n${results.filter((r) => r[1]).length}/${results.length} checks passed`)
  process.exit(results.every((r) => r[1]) ? 0 : 1)
}
